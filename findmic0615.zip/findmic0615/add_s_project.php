<?php
	if(!isset($_COOKIE["account_name"])){
		echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please login!"."\"".")".";"."</script>";
        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
		
	}else{
		if($_COOKIE["type"]=="c"){
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please add project here!"."\"".")".";"."</script>";
			echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."add_c_project.html"."\""."</script>";
		}
	}
	// Opens a connection to a MySQL server
	include_once("connect.php");
	$project_name=addslashes($_POST["project_name"]);
	$ground_area=$_POST["ground_area"];
	$address=addslashes($_POST["address"]);
	$latitude=$_POST["latitude"];
	$longitude=$_POST["longitude"];
	$storey=$_POST["storey"];
	if($project_name==""||$ground_area==""||$address==""||$latitude==""||$longitude=="")
      {
        echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please fill info!"."\"".")".";"."</script>";
        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."add_c_project.html"."\""."</script>";
        exit;
      }
	$building_type=$_POST["building_type"];
	$structure_type=$_POST["structure_type"];
	$company=addslashes($_COOKIE['company']);
		 // Select all the rows in the projects table
		$querys = "insert into project(project_name,storey,module_contractor,ground_area,address,latitude,longitude,building_type,structure_type) values('$project_name','$storey','$company','$ground_area','$address','$latitude','$longitude','$building_type','$structure_type');";
		$results = mysqli_query($connection,$querys);
		if ($results=="")
		{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Add Failure! Please add again"."\"".")".";"."</script>";
			echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."add_c_project.html"."\""."</script>";   
		}
		else{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Add Success!"."\"".")".";"."</script>";
			header("location:info_supplier.php");
		}
	
?>
