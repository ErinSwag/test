﻿<?php
	
	// Opens a connection to a MySQL server
	include_once("connect.php");
  $account_name=$_POST["account_name"];
  $password=$_POST["password"];
  $type=$_POST["type"];
  
  
	if($account_name==""||$password=="")
      {
        echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please fill info!"."\"".")".";"."</script>";
        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
        exit;
      }
	// Select all the rows in the projects table
	if($type=='c'){
		$querys = "SELECT password,sn FROM customer where account_name = '$account_name'";
		$results = mysqli_query($connection,$querys);
		$rowp = @mysqli_fetch_assoc($results);
		if ($rowp=="")
		{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Account Failure"."\"".")".";"."</script>";
			echo "<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";   
		}
		else if($password==$rowp["password"]){
			setcookie("sn",$rowp["sn"],time()+3600);
			setcookie("account_name",$account_name,time()+3600);
			setcookie("password",$password,time()+3600);
			setcookie("type",$type,time()+3600);
			header("location:info_customer.php");
		}else{
			echo "<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Password Failure"."\"".")".";"."</script>";
			echo "<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
		}
	}else{
		$querys = "SELECT password,sn,company FROM supplier where account_name = '$account_name'";
		$results = mysqli_query($connection,$querys);
		$rowp = @mysqli_fetch_assoc($results);
		if ($rowp=="")
		{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."aAccount Failure"."\"".")".";"."</script>";
			echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";   
		}
		else if($password==$rowp["password"]){
			setcookie("company",$rowp["company"],time()+3600);
			setcookie("sn",$rowp["sn"],time()+3600);
			setcookie("account_name",$account_name,time()+3600);
			setcookie("password",$password,time()+3600);
			setcookie("type",$type,time()+3600);
			header("location:info_supplier.php");
		}
		else{
			echo "<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."aPassword Failure"."\"".")".";"."</script>";
			echo "<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
		}
	}
?>