<?php
	if(!isset($_COOKIE["account_name"])){
		echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please login!"."\"".")".";"."</script>";
        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
		
	}else{
		if($_COOKIE["type"]=="s"){
			header("location:list_map_suppliers.php");
		}
		else if($_COOKIE["type"]=="c"){
			$url=$_SERVER["QUERY_STRING"]."<br>";
			parse_str($url, $output);
			$sn=trim($output['sn']);
			$c_sn=$_COOKIE["sn"];
			include_once("connect.php");
			// Select all the rows in the projects table
			$queryco = "insert into following_supplier(customer_sn,supplier_sn) values('$c_sn','$sn');";
			$resultco = mysqli_query($connection,$queryco);
			if ($resultco=="")
			{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Collect Failure! Please Collect again"."\"".")".";"."</script>";
			echo $queryco;
			//echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."list_map_suppliers.php"."\""."</script>";   
			}
			else{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Collect Success!"."\"".")".";"."</script>";
			header("location:list_map_suppliers.php");
			}
		}
	}
?>