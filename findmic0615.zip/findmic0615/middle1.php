<?php
	if(isset($_COOKIE["account_name"])){
		if($_COOKIE["type"]=="c"){
			header("location:add_c_project.html");
		}
		if($_COOKIE["type"]=="s"){
			header("location:add_s_project.html");
		}
	}else{
		echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please login!"."\"".")".";"."</script>";
        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
	}
?>