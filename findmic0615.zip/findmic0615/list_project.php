<!DOCTYPE html>
<html lang="utf-8">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Find easily a supplier and book online an appointment">
	<meta name="author" content="Ansonika">
	<title>MIC - Find easily a supplier and book online an appointment</title>

	<!-- Favicons-->
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">

	<!-- BASE CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/menu.css" rel="stylesheet">
	<link href="css/vendors.css" rel="stylesheet">
	<link href="css/icon_fonts/css/all_icons_min.css" rel="stylesheet">
   
    <!-- SPECIFIC CSS -->
    <link href="css/date_picker.css" rel="stylesheet">
    
	<!-- YOUR CUSTOM CSS -->
	<link href="css/custom.css" rel="stylesheet">
	<style type="text/css">

*{ margin:0px; padding:0px;}

 #menu{ background-color:#eee; width:600px; height:40px; margin:0 auto;}

 #test ul{ list-style:none;}

 #test ul li{ line-height:40px; text-align:center; position:relative; float:left;}

#test a{ text-decoration:none; color:#000; display:block; width:90px;}

 #test a:hover{ color:#FFF; background-color:#666;}

#test ul li ul li{ float:none;margin-top:2px; background-color:#eee; } 

#test ul li ul{width:90px; position:absolute;display:none;  }

#test ul li:hover ul{display:block;}

</style>	

</head>

<body>
	<div class="layer"></div>
	<!-- Mobile menu overlay mask -->

	<div id="preloader">
		<div data-loader="circle-side"></div>
	</div>
	<!-- End Preload -->
    
	<header class="header_sticky">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div id="logo_home">
                            <h1><a href="index.html" title="FindMiC">FindMiC</a></h1>
                        </div>
                    </div>
                    <nav class="col-lg-9 col-6">
					<div>
                        <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="#0"><span>Menu mobile
						
						</span></a>
					</div>
					<div id="test">
                        <ul id="top_access">
                            <li><i class="pe-7s-user"></i>
							<div>
							<ul>
						<li><a href="middle.php">My Home Page</a></li>
						<li><a href="login.html">Login</a></li>
						<li><a href="javascript:void(0)" onclick="logout()">Logout</a></li>
						</ul>
							</div>
							</li>
							<script>
							$('i.pe-7s-user').hover(function(){
        $(this).find('ul').show();
    },function(){
        $(this).find('ul').hide();
    });
							</script>
                        </ul>
						</div>
                        <div class="main-menu">
                            <ul>
                                <li class="submenu">
                                    <a href="index.html" class="show-submenu">Home</a>
                                   
                                </li>
                                <li class="submenu">
                                    <a href="list_map_normal.php"  class="show-submenu">Database</a>
                                    
                                </li>
                                <li><a href="contacts.html">Contact Us</a></li>
                            </ul>
                        </div>
                        <!-- /main-menu -->
                    </nav>
                </div>
            </div>
        </header>
		<script>
						function logout(){
							setCookie("account_name","");
							setCookie("sn","");
							setCookie("type","");
							setCookie("company","");
							setCookie("password","");
							window.location.href="index.html";
						}
						
function setCookie(cname, cvalue, exdays) {

    var d = new Date();

    d.setTime(d.getTime() + (exdays*24*60*60*1000));

    var expires = "expires="+d.toUTCString();

    document.cookie = cname + "=" + cvalue + "; " + expires;

}
						</script>
	<!-- /Header -->
	
	<main>
		<div id="breadcrumb">
			<div class="container">
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="#">Project Information</a></li>
				</ul>
			</div>
		</div>
		<!-- /breadcrumb -->
		
		<div class="container margin_60">
			<div class="row">
				
				<aside class="col-xl-3 col-lg-4" id="sidebar">
					<div class="box_profile">
						<br />
						<?php
						$url=$_SERVER["QUERY_STRING"]."<br>";
						parse_str($url, $output);
						$sn=$output['sn'];
						include_once("connect.php");
						$querys = "SELECT * FROM project where project.sn = '$sn'";
						$results = mysqli_query($connection,$querys);
						$rows = @mysqli_fetch_assoc($results);
							if ($rows=="")
							{
								echo "No Results";     
							}
							else{
								mysqli_data_seek($results,0);
								$row=$results->fetch_assoc();
								echo "<figure>
										<img src='".$row['image']."' alt='' class='img-fluid'>
									</figure>";
								echo "<h3>".$row['project_name']."</h3>";
								
								
							}	
						?>
						<div class="text-center"><?php
							echo "<a href='list_map_normal.php?latitude=".$row['latitude']."&longitude=".$row["longitude"]."&typemap=p' class='btn_1 outline' target='_blank'>";
						?><i class="icon_pin"></i> View on map</a></div>
					</div>
				</aside>
				<!-- /asdide -->
				
				<div class="col-xl-9 col-lg-8">

					<div class="tabs_styled_2">
						<ul class="nav nav-tabs" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" id="general-tab" data-toggle="tab" href="#general" role="tab" aria-controls="general" aria-expanded="true">Project Information</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="reviews-tab" data-toggle="tab" href="#reviews" role="tab" aria-controls="reviews">Other Inforatmion</a>
							</li>
						</ul>
						<!--/nav-tabs -->

						<div class="tab-content">


						<div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
							   
								<div class="indent_title_in">
									<i class="pe-7s-note2"></i> 
									<span class="italic"><h3><?php echo $row['project_name']?></h3></span>		
								</div>
								<p></p>
								<div class="wrapper_indent">
									
									<h6>Project Duration</h6>
									<div class="row">
										<div class="col-lg-12">
											<ul class="bullets">
												<li>Start Date <?php echo $row['beginning_date']?></li>
												<li>Completion Date <?php echo $row['completion_date']?></li>
											</ul>
											<hr>
											<h6>Project Stakeholders</h6>
								
								
											<ul class="bullets">
												<li>Owner <?php echo $row['owner']?></li>
												<li>Main Contractor <?php echo $row['main_contractor']?></li>
												<li>Module Contractor <?php echo $row['module_contractor']?></li>
											</ul>
											<hr>
											<h6>Project Location</h6>
									
									
											<ul class="bullets">
												<li>Country <?php echo $row['country']?></li>
												<li>Address <?php echo $row['address']?></li>
											</ul>	
											<hr>
											<h6>Brief Introduction</h6>
											<div class="row" id="2_div">
										          
													<p><?php echo $row['brief_introduction']?></p>
											</div>										
										</div>
									</div>
									<!-- /row-->
								</div>
								<!-- /wrapper indent -->
								
								<hr>
								

								<div class="indent_title_in">
									<i class="pe-7s-home"></i>
									<h3>Building Type</h3>
									
								</div>
								<p></p>
								<div class="wrapper_indent">
								
				
									<ul class="treatments clearfix">
										<li>
											<div class="checkbox">
												<strong><?php 
												echo $row['building_type']
												?></strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
									</ul>
								</div>
								<!--  End wrapper indent -->
								<hr>

								<div class="indent_title_in">
									<i class="pe-7s-news-paper"></i>
									<h3>Structure Type</h3>
									
								</div>
								<div class="wrapper_indent">
									<ul class="treatments clearfix">
										<li>
											<div class="checkbox">
												<strong><?php echo $row['structure_type']?></strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
									</ul>
								</div>
								<!--  End wrapper indent -->

									

						</div>
							<!-- /tab_1 -->

							<div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab">
								<div class="indent_title_in">
									<i class="pe-7s-cash"></i>
									<h3></h3>
								</div>
								<!-- <br />
								<img src="img/operating1.jpg" width="750px" height="510px" alt="">
								<br />
								<img src="img/operating2.jpg" width="750px" height="510px" alt="">
								<br />
								<div class="wrapper_indent">
								<br />
								<p><a href="http://www.moduleco.com/projects.php">CLICK HERE</a> To Learn More</p>
								</div> -->
								<!-- End review-container -->
							</div>
							<!-- /tab_2 -->
						</div>
						<!-- /tab-content -->
					</div>
					<!-- /tabs_styled -->
				</div>
				<!-- /col -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</main>
	<!-- /main -->
	
	<footer>
		<div class="container margin_60_35">
			<div class="row">
				<div class="col-lg-3 col-md-12">
					<p>
						<a href="index.html" title="MIC">
							<img src="img/logo.png" data-retina="true" alt="" width="163" height="36" class="img-fluid">
						</a>
					</p>
				</div>
				<div class="col-lg-3 col-md-4">
					<h5>About</h5>
					<ul class="links">
						<li><a href="#0">About us</a></li>
						<li><a href="blog.html">Blog</a></li>
						<li><a href="#0">FAQ</a></li>
						<li><a href="login.html">Login</a></li>
						<li><a href="register.html">Register</a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-4">
					<h5>Useful links</h5>
					<ul class="links">
						<li><a href="#0">Suppliers</a></li>
						<li><a href="#0">Clinics</a></li>
						<li><a href="#0">Specialization</a></li>
						<li><a href="#0">Join as a Supplier</a></li>
						<li><a href="#0">Download App</a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-4">
					<h5>Contact with Us</h5>
					<ul class="contacts">
						<li><a href="tel://61280932400"><i class="icon_mobile"></i> + 852 XXXXXXXX</a></li>
						<li><a href="mailto:info@findMIC.com"><i class="icon_mail_alt"></i> help@XX.com</a></li>
					</ul>
					<div class="follow_us">
						<h5>Follow us</h5>
						<ul>
							<li><a href="#0"><i class="social_facebook"></i></a></li>
							<li><a href="#0"><i class="social_twitter"></i></a></li>
							<li><a href="#0"><i class="social_linkedin"></i></a></li>
							<li><a href="#0"><i class="social_instagram"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
			<!--/row-->
			<hr>
			<div class="row">
				<div class="col-md-8">
					<ul id="additional_links">
						<li><a href="#0">Terms and conditions</a></li>
						<li><a href="#0">Privacy</a></li>
					</ul>
				</div>
				<div class="col-md-4">
					<div id="copy">© 2019 MIC</div>
				</div>
			</div>
		</div>
	</footer>
	<!--/footer-->

	<div id="toTop"></div>
	<!-- Back to top button -->

	<!-- COMMON SCRIPTS -->
	<script src="js/jquery-2.2.4.min.js"></script>
	<script src="js/common_scripts.min.js"></script>
	<script src="js/functions.js"></script>
   	
	<!-- SPECIFIC SCRIPTS -->
    <script src="js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
			todayHighlight: true,
			daysOfWeekDisabled: [0],
			weekStart: 1,
			format: "yyyy-mm-dd",
			datesDisabled: ["2017/10/20", "2017/11/21", "2017/12/21", "2018/01/21", "2018/02/21", "2018/03/21"],
		});
	</script>
     
</body>
</html>
