<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Find easily a doctor and book online an appointment">
	<meta name="author" content="Ansonika">
	<title>FINDMIC</title>

	<!-- Favicons-->
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">

	<!-- BASE CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/menu.css" rel="stylesheet">
	<link href="css/vendors.css" rel="stylesheet">
	<link href="css/icon_fonts/css/all_icons_min.css" rel="stylesheet">
   
    <!-- SPECIFIC CSS -->
    <link href="css/date_picker.css" rel="stylesheet">
    
	<!-- YOUR CUSTOM CSS -->
	<link href="css/custom.css" rel="stylesheet">
<style type="text/css">

*{ margin:0px; padding:0px;}

 #menu{ background-color:#eee; width:600px; height:40px; margin:0 auto;}

 #test ul{ list-style:none;}

 #test ul li{ line-height:40px; text-align:center; position:relative; float:left;}

#test a{ text-decoration:none; color:#000; display:block; width:90px;}

 #test a:hover{ color:#FFF; background-color:#666;}

#test ul li ul li{ float:none;margin-top:2px; background-color:#eee; } 

#test ul li ul{width:90px; position:absolute;display:none;  }

#test ul li:hover ul{display:block;}

</style>	
</head>

<body>

	<div class="layer"></div>
	<!-- Mobile menu overlay mask -->

	<div id="preloader">
		<div data-loader="circle-side"></div>
	</div>
	<!-- End Preload -->
    
	<header class="header_sticky">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div id="logo_home">
                            <h1><a href="index.html" title="FindMiC">FindMiC</a></h1>
                        </div>
                    </div>
                    <nav class="col-lg-9 col-6">
					<div>
                        <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="#0"><span>Menu mobile
						
						</span></a>
					</div>
					<div id="test">
                        <ul id="top_access">
                            <li><i class="pe-7s-user"></i>
							<div>
							<ul>
						<li><a href="middle.php">My Home Page</a></li>
						<li><a href="login.html">Login</a></li>
						<li><a href="javascript:void(0)" onclick="logout()">Logout</a></li>
						</ul>
							</div>
							</li>
							<script>
							$('i.pe-7s-user').hover(function(){
        $(this).find('ul').show();
    },function(){
        $(this).find('ul').hide();
    });
							</script>
                        </ul>
						</div>
                        <div class="main-menu">
                            <ul>
                                <li class="submenu">
                                    <a href="index.html" class="show-submenu">Home</a>
                                   
                                </li>
                                <li class="submenu">
                                    <a href="list_map_normal.php"  class="show-submenu">Database</a>
                                    
                                </li>
                                <li><a href="contacts.html">Contact Us</a></li>
                            </ul>
                        </div>
                        <!-- /main-menu -->
                    </nav>
                </div>
            </div>
        </header>
		<script>
						function logout(){
							setCookie("account_name","");
							setCookie("sn","");
							setCookie("type","");
							setCookie("company","");
							setCookie("password","");
							window.location.href="index.html";
						}
						
function setCookie(cname, cvalue, exdays) {

    var d = new Date();

    d.setTime(d.getTime() + (exdays*24*60*60*1000));

    var expires = "expires="+d.toUTCString();

    document.cookie = cname + "=" + cvalue + "; " + expires;

}
						</script>
	<!-- /Header -->
	
	<main>
		<div id="breadcrumb">
			<div class="container">
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="#">Update a project</a></li>
				</ul>
			</div>
		</div>
		<!-- /breadcrumb -->
		

			
				<div class="col-xl-12 col-lg-8">
					<div class="tabs_styled_2">
						<ul class="nav nav-tabs" role="tablist">
						</ul>
						<!--/nav-tabs -->

						
						<?php
							$sn=$_GET['sn'];
							include_once("connect.php");
						$querys = "SELECT * FROM project where project.sn = '$sn'";
						$results = mysqli_query($connection,$querys);
						$rows = @mysqli_fetch_assoc($results);
							if ($rows=="")
							{
								echo "No Results";     
							}
							else{
								mysqli_data_seek($results,0);
								$row=$results->fetch_assoc();		
								
							}	
						?>
						<div class="tab-content">

							<div class="tab-pane fade show active" id="book" role="tabpanel" aria-labelledby="book-tab">
							
								<form action="update_s_project.php" method="post">
									<div class="main_title_3">
										<h3><strong>1</strong>PROJECT BASIC</h3>
									</div>

								<input type="hidden" name="sn" value="<?php echo $sn; ?>">
								<div class="box_form">
									<div class="form-group">
										<label>Project Name</label>
										<input type="text" name="project_name" id="project_name" value="<?php echo $row['project_name']; ?>" class="form-control" placeholder="Ex. Andersion Road Project">
									</div>
									<div class="row">
									<div class="col-md-6">
									<div class="form-group">
										<label>Ground Area</label>
										<input type="text" name="ground_area" id="ground_area" value="<?php echo $row['ground_area']; ?>" class="form-control" placeholder="Input m2">
									</div>
									</div>
									<div class="col-md-6">
									<div class="form-group">
										<label>Storey</label>
										<input type="text" name="storey" id="storey" value="<?php echo $row['storey']; ?>" class="form-control" placeholder="Input F">
									</div>
									</div>
									</div>
									<!-- <div class="row">
									<div class="col-md-6">
									 <div class="form-group">
										<label>Site Area</label>
										<input type="text" class="form-control" placeholder="Input m2">
									 </div>
									</div>
									<div class="col-md-6" >
									 <div class="form-group">
										<label>Height</label>
										<input type="text" class="form-control" placeholder="Input m">
									 </div>
									</div>
									</div> -->
								<!-- /row --> 
									
									
									<div class="form-group">
										<label>Address</label>
										<input type="location" name="address" id="address" value="<?php echo $row['address']; ?>" class="form-control" placeholder="Ex. No.24 Queen's Road, Hong Kong">
									</div>
									<div class="row">
									<div class="col-md-6">
									<div class="form-group">
										<label>latitude</label>
										<input type="location" name="latitude" id="latitude" value="<?php echo $row['latitude']; ?>" class="form-control" placeholder="Ex. 22.223">
									</div>
									</div>
									<div class="col-md-6">
									<div class="form-group">
										<label>longitude</label>
										<input type="location" name="longitude" id="longitude" value="<?php echo $row['longitude']; ?>" class="form-control" placeholder="Ex. 114.3476">
									</div>
									</div>
									</div>
								</div>
									
									<div class="main_title_3">
										<h3><strong>2</strong>Select building type</h3>
									</div>  
								
									<ul class="treatments clearfix">
										<li>
											<input type="radio" class="css-radio" value="housing/residential" name="building_type">&nbsp;&nbsp;housing/residential
										</li>
										<li>
											<input type="radio" class="css-radio" value="accommodation" name="building_type">&nbsp;&nbsp;accommodation
										</li>
										<li>
											<input type="radio" class="css-radio" value="school" name="building_type">&nbsp;&nbsp;school
										</li>
										<li>
											<input type="radio" class="css-radio" value="office" name="building_type">&nbsp;&nbsp;office
										</li>
										<li>
											<input type="radio" class="css-radio" value="health_services_building" name="building_type">&nbsp;&nbsp;health services building
										</li>
										<li>
											<input type="radio" class="css-radio" value="hotels" name="building_type">&nbsp;&nbsp;hotels
										</li>
										<li>
											<input type="radio" class="css-radio" value="retail" name="building_type">&nbsp;&nbsp;retail
										</li>
										<li>
											<input type="radio" class="css-radio" value="factories" name="building_type">&nbsp;&nbsp;factories
										</li>
										<li>
											<input type="radio" class="css-radio" value="canteens" name="building_type">&nbsp;&nbsp;canteens
										</li>
										<li>
											<input type="radio" class="css-radio" value="sports_center_dance_studios" name="building_type">&nbsp;&nbsp;sports center dance studios
										</li>
										<li>
											<input type="radio" class="css-radio" value="mobile_unites_for_events" name="building_type">&nbsp;&nbsp;mobile unites for events
										</li>
										<li>
											<input type="radio" class="css-radio" value="storage" name="building_type">&nbsp;&nbsp;storage
										</li>
										<li>
											<input type="radio" class="css-radio" value="laboratories" name="building_type">&nbsp;&nbsp;laboratories
										</li>
									</ul>
									
									<div class="main_title_3">
										<h3><strong>3</strong>Select structure type</h3>
									</div>
									<ul class="treatments clearfix">
										<li>
											<div class="checkbox">
												<input type="radio" class="css-checkbox" name="structure_type" value="concrete">&nbsp;&nbsp;Concrete
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="radio" class="css-checkbox" name="structure_type" value="steel">&nbsp;&nbsp;Steel
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="radio" class="css-checkbox" name="structure_type" value="composite">&nbsp;&nbsp;Composite
											</div>
										</li>
									</ul>
									<div class="checkbox-holder text-left">
										
									</div>
									<div class="form-group text-center add_top_30">
										<input class="btn_1" type="submit" value="Update A Project" id="btn_add">
									</div>
								</form>					
								
							</div>
							<!-- /tab_1 -->
							
							
						</div>
						<!-- /tab-content -->
					</div>
					<!-- /tabs_styled -->
				</div>
				<!-- /col -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</main>
	<!-- /main -->
	
        <footer>
            <div class="container margin_60_35">
                <div class="row">
                    <div class="col-lg-3 col-md-12">
                        <p>
                       
                                <a href="index.html" title="FindMIC"><img src="img/logo.png" data-retina="true" alt="" width="163" height="36"></a>
                        </p>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <h5>About</h5>
                        <ul class="links">
                            <li><a href="contacts.html">About us</a></li>
                            <li><a href="login.html">Login</a></li>
                            <li><a href="register_supplier.html">Register</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <h5>Useful links</h5>
                        <ul class="links">
                            <li><a href="http://www.civil.hku.hk/cicid/3_events.htm">HKCICID</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <h5>Contact with Us</h5>
                        <ul class="contacts">
                            <li><a href="tel://61280932400"><i class="icon_mobile"></i> To be announced</a></li>
                            <li><a href="mailto:info@findoctor.com"><i class="icon_mail_alt"></i> help@findmic.com</a></li>
                        </ul>
                        <div class="follow_us">
                            <h5>Follow us</h5>
                            <ul>
                                <li><a href="#0"><i class="social_facebook"></i></a></li>
                                <li><a href="#0"><i class="social_twitter"></i></a></li>
                                <li><a href="#0"><i class="social_linkedin"></i></a></li>
                                <li><a href="#0"><i class="social_instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--/row-->
                <hr>
                <div class="row">
                    <div class="col-md-8">
                        <ul id="additional_links">
                            <li><a href="#0">Terms and conditions</a></li>
                            <li><a href="#0">Privacy</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <div id="copy">© 2018 FindMiC</div>
                    </div>
                </div>
            </div>
        </footer>
        <!--/footer-->
        
        <div id="toTop"></div>
        <!-- Back to top button -->
        
        <!-- COMMON SCRIPTS -->
        <script src="js/jquery-2.2.4.min.js"></script>
        <script src="js/common_scripts.min.js"></script>
        <script src="js/functions.js"></script>
        
    </body>
    
</html>