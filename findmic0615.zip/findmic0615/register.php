<?php
	// Opens a connection to a MySQL server
	include_once("connect.php");
	$account_name=$_POST["account_name"];
	$password=$_POST["password"];
	$email=$_POST["email"];
	$company=$_POST["company"];
	$type=$_POST["type"];
	
	if($account_name==""||$password=="")
      {
        echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please fill info!"."\"".")".";"."</script>";
        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."register_customer.html"."\""."</script>";
        exit;
      }
	if($type=='c'){
		 // Select all the rows in the projects table
		$querys = "insert into customer(account_name,password,email,company) values('$account_name','$password','$email','$company');";
		$results = mysqli_query($connection,$querys);
		if ($results=="")
		{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Register Failure! Please register again"."\"".")".";"."</script>";
			echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."register.html"."\""."</script>";   
		}
		else{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Register Success!"."\"".")".";"."</script>";
			header("location:login.html");
		}
	 }else if($type='s'){
		 // Select all the rows in the projects table
		$querys = "insert into supplier(account_name,password,email,company) values('$account_name','$password','$email','$company');";
		$results = mysqli_query($connection,$querys);
		if ($results=="")
		{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Register Failure! Please register again"."\"".")".";"."</script>";
			echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."register.html"."\""."</script>";   
		}
		else{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Register Success!"."\"".")".";"."</script>";
			header("location:login.html");
		} 
	 }
	
?>
