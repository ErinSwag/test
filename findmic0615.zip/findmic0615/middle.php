<?php
	if(isset($_COOKIE["account_name"])){
		if($_COOKIE["type"]=="c"){
			header("location:info_customer.php");
		}
		if($_COOKIE["type"]=="s"){
			header("location:info_supplier.php");
		}
		if($_COOKIE["type"]==""){
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please login!"."\"".")".";"."</script>";
			echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
		}
	}else{
		echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please login!"."\"".")".";"."</script>";
        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
	}
?>