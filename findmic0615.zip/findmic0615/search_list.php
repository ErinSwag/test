<!DOCTYPE html>
<html lang="en">
    
    <head>
        <meta charset="UTF-8-sig">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <meta name="description" content="Find easily a doctor and book online an appointment">
                        <meta name="author" content="Ansonika">
                            <title>FindMiC: find the best-fit MiC suppliers for you</title>
                            <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
                                <link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
                                    <link rel="apple-tou ch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
                                        <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
                                            <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">
                                                
                                                <!-- BASE CSS -->
                                                <link href="css/bootstrap.min.css" rel="stylesheet">
												<link rel="stylesheet" href="css/jquery.ui.autocomplete.css">
                                                    <link href="css/style.css" rel="stylesheet">
                                                        <link href="css/menu.css" rel="stylesheet">
                                                            <link href="css/vendors.css" rel="stylesheet">
                                                                <link href="css/icon_fonts/css/all_icons_min.css" rel="stylesheet">
                                                                    
                                                                    <!-- YOUR CUSTOM CSS -->
                                                                    <link href="css/custom.css" rel="stylesheet">
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
		<script type="text/javascript" src="ui/jquery.ui.core.js"></script>
		<script type="text/javascript" src="ui/jquery.ui.widget.js"></script>
		<script type="text/javascript" src="ui/jquery.ui.position.js"></script>
		<script type="text/javascript" src="ui/jquery.ui.autocomplete.js"></script>
             	<style type="text/css">

*{ margin:0px; padding:0px;}

 #menu{ background-color:#eee; width:600px; height:40px; margin:0 auto;}

 #test ul{ list-style:none;}

 #test ul li{ line-height:40px; text-align:center; position:relative; float:left;}

#test a{ text-decoration:none; color:#000; display:block; width:90px;}

 #test a:hover{ color:#FFF; background-color:#666;}

#test ul li ul li{ float:none;margin-top:2px; background-color:#eee; } 

#test ul li ul{width:90px; position:absolute;display:none;  }

#test ul li:hover ul{display:block;}

</style>                                                     
    </head>
    
    <body>
        
        <div class="layer"></div>
        <!-- Mobile menu overlay mask -->
        
        <div id="preloader">
            <div data-loader="circle-side"></div>
        </div>
        <!-- End Preload -->
        
        <header class="header_sticky">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div id="logo_home">
                            <h1><a href="index.html" title="FindMiC">FindMiC</a></h1>
                        </div>
                    </div>
                    <nav class="col-lg-9 col-6">
					<div>
                        <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="#0"><span>Menu mobile
						
						</span></a>
					</div>
					<div id="test">
                        <ul id="top_access">
                            <li><i class="pe-7s-user"></i>
							<div>
							<ul>
						<li><a href="middle.php">My Home Page</a></li>
						<li><a href="login.html">Login</a></li>
						<li><a href="javascript:void(0)" onclick="logout()">Logout</a></li>
						</ul>
							</div>
							</li>
							<script>
							$('i.pe-7s-user').hover(function(){
        $(this).find('ul').show();
    },function(){
        $(this).find('ul').hide();
    });
							</script>
                        </ul>
						</div>
                        <div class="main-menu">
                            <ul>
                                <li class="submenu">
                                    <a href="index.html" class="show-submenu">Home</a>
                                   
                                </li>
                                <li class="submenu">
                                    <a href="list_map_normal.php"  class="show-submenu">Database</a>
                                    
                                </li>
                                <li><a href="contacts.html">Contact Us</a></li>
                            </ul>
                        </div>
                        <!-- /main-menu -->
                    </nav>
                </div>
            </div>
        </header>
		<script>
						function logout(){
							setCookie("account_name","");
							setCookie("sn","");
							setCookie("type","");
							setCookie("company","");
							setCookie("password","");
							window.location.href="index.html";
						}
						
function setCookie(cname, cvalue, exdays) {

    var d = new Date();

    d.setTime(d.getTime() + (exdays*24*60*60*1000));

    var expires = "expires="+d.toUTCString();

    document.cookie = cname + "=" + cvalue + "; " + expires;

}
						</script>
	
        <!-- /header -->
        
        <main>           
            <div class="container margin_120_95">
                
                <div class="row justify-content-center">
                    <div class="col-xl-4 col-lg-5 col-md-6">
                        <div class="list_home">
                            <div class="list_title">
                                <i class="icon_pin_alt"></i>
                                <h3>Suppliers Result</h3>
                            </div>
                            <ul>
							<?php
							$sname = $_POST['key'];              
							if($sname == ""){                  
								echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please fill keyword!"."\"".")".";"."</script>";
								echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."index.html"."\""."</script>";            
							}              
							else{
								// Opens a connection to a MySQL server
								include_once("connect.php");

								// Select all the rows in the projects table
								$querys = "SELECT * FROM supplier where company LIKE '%$sname%'";
								$results = mysqli_query($connection,$querys);
								
								$rows = @mysqli_fetch_assoc($results);
								
								if ($rows=="")
								{
									echo "<li><a href=\"#0\" id=\"su\"><strong>"."1"."</strong>" . "No Results". "</a></li>"; 
								}
								else{
									mysqli_data_seek($results,0);
									$i=1;
									 while($rowss = $results->fetch_assoc()) {
										echo "<li><a href='list_supplier.php?sn=".$rowss['sn']."'><strong>".$i."</strong>". $rowss['company']."</a></li>";
										$i++;
									}
								}									   
							}
							?>
                            <script>
							document.getElementById('su').setAttribute("disabled",true).css("pointer-events","none"); 
							</script>   
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-5 col-md-6">
                        <div class="list_home">
                            <div class="list_title">
                                <i class="icon_archive_alt"></i>
                                <h3>Projects Result</h3>
                            </div>
                            <ul>
                                <?php
							$pname = $_POST['key'];              
							if($pname == ""){
								echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please fill keyword!"."\"".")".";"."</script>";
								echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."index.html"."\""."</script>";          
							}              
							else{
								// Opens a connection to a MySQL server
								include_once("connect.php");
								
								// Select all the rows in the projects table

								$queryp = "SELECT * FROM project where project_name LIKE '%$pname%'";
								$resultp = mysqli_query($connection,$queryp);
								$rowp = @mysqli_fetch_assoc($resultp);
								
								if ($rowp=="")
								{
									echo "<li><a href=\"#0\" id=\"pr\"><strong>"."1"."</strong>" . "No Results". "</a></li>";    
								}
								else{
									mysqli_data_seek($resultp,0);
									$i=1;
									echo "
							﻿";
									 while($rowpp = $resultp->fetch_assoc()) {
										echo "<li><a href=\"list_project.php?sn=". $rowpp['sn']."\"><strong>".$i."</strong>" . $rowpp['project_name']. "</a></li>";
										$i++;
									}
									
								}								   
							}
							?>
							<script>
							document.getElementById('pr').setAttribute("disabled",true).css("pointer-events","none");  
							</script>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
          
        </main>
        <!-- /main content -->
        
        <footer>
            <div class="container margin_60_35">
                <div class="row">
                    <div class="col-lg-3 col-md-12">
                        <p>
                        <a href="index.html" title="Findoctor">
                            <img src="img/logo.png" data-retina="true" alt="" width="163" height="36" class="img-fluid">
                                </a>
                        </p>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <h5>About</h5>
                        <ul class="links">
                            <li><a href="#0">About us</a></li>
                            <li><a href="blog.html">Blog</a></li>
                            <li><a href="#0">FAQ</a></li>
                            <li><a href="login.html">Login</a></li>
                            <li><a href="register.html">Register</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <h5>Useful links</h5>
                        <ul class="links">
                            <li><a href="#0">HKCICID</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <h5>Contact with Us</h5>
                        <ul class="contacts">
                            <li><a href="tel://61280932400"><i class="icon_mobile"></i> To be announced</a></li>
                            <li><a href="mailto:info@findoctor.com"><i class="icon_mail_alt"></i> help@findmic.com</a></li>
                        </ul>
                        <div class="follow_us">
                            <h5>Follow us</h5>
                            <ul>
                                <li><a href="#0"><i class="social_facebook"></i></a></li>
                                <li><a href="#0"><i class="social_twitter"></i></a></li>
                                <li><a href="#0"><i class="social_linkedin"></i></a></li>
                                <li><a href="#0"><i class="social_instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--/row-->
                <hr>
                <div class="row">
                    <div class="col-md-8">
                        <ul id="additional_links">
                            <li><a href="#0">Terms and conditions</a></li>
                            <li><a href="#0">Privacy</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <div id="copy">© 2018 FindMiC</div>
                    </div>
                </div>
            </div>
        </footer>
        <!--/footer-->
        
        <div id="toTop"></div>
        <!-- Back to top button -->
        
        <!-- COMMON SCRIPTS -->
        <script src="js/jquery-2.2.4.min.js"></script>
        <script src="js/common_scripts.min.js"></script>
        <script src="js/functions.js"></script>
        
    </body>
    
</html>
