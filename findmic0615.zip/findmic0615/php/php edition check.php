<?php
echo 'Current PHP version LoL: ' . phpversion();
?>