<?php

// Start XML file, create parent node

$dom = new DOMDocument("1.0");
$node = $dom->createElement("projects");
$parnode = $dom->appendChild($node);

// Opens a connection to a MySQL server
define("DB_HOST","47.244.185.245");
define("DB_USER","root");
define("DB_PASS","Cicid2019");
define("DB_NAME","mic");
define("DB_PORT","3306");
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
if (mysqli_connect_error())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
} 
$sn=$_COOKIE["sn"];
// Select all the rows in the projects table

$query = "SELECT * FROM collecting_project where customer_sn='$sn'";
$result = mysqli_query($connection,$query);
if (!$result)
{
echo("Error description: " . mysqli_error($connection));
}

// Iterate through the rows, adding XML nodes for each

header("Content-type: text/xml");

while ($row = @mysqli_fetch_assoc($result)){
  // Add to XML document node
  $node = $dom->createElement("project");
  $newnode = $parnode->appendChild($node);
  $newnode->setAttribute("Name",$row['project_name']);
  $newnode->setAttribute("img",$row['image']);
  $newnode->setAttribute("address",$row['address']);
  $newnode->setAttribute("date",$row['beginning_date']);
  $newnode->setAttribute("storey",$row['storey']);
  $newnode->setAttribute("area",$row['ground_area']);
  $newnode->setAttribute("Lat", $row['latitude']);
  $newnode->setAttribute("Lng", $row['longitude']);
  $newnode->setAttribute("stype", $row['structure_type']);
}

echo $dom->saveXML();

?>
