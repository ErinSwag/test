<?php

// Start XML file, create parent node

$dom = new DOMDocument("1.0");
$node = $dom->createElement("suppliers");
$parnode = $dom->appendChild($node);

// Opens a connection to a MySQL server
define("DB_HOST","47.244.185.245");
define("DB_USER","root");
define("DB_PASS","Cicid2019");
define("DB_NAME","mic");
define("DB_PORT","3306");
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
if (mysqli_connect_error())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
} 

// Select all the rows in the projects table

$query = "SELECT supplier.sn AS sn, supplier.logo AS logo, supplier.company AS company, supplier.latitude AS latitude, supplier.longitude AS longitude, supplier.address AS address, structure_type.concrete AS concrete, structure_type.steel AS steel, structure_type.composite AS composite FROM supplier,structure_type where supplier.structure_type=structure_type.sn";
$result = mysqli_query($connection,$query);
if (!$result)
{
echo("Error description: " . mysqli_error($connection));
}

// Iterate through the rows, adding XML nodes for each

header("Content-type: text/xml");

while ($row = @mysqli_fetch_assoc($result)){
  // Add to XML document node
  $node = $dom->createElement("supplier");
  $newnode = $parnode->appendChild($node);
  $newnode->setAttribute("SupplierID",$row['sn']);
  $newnode->setAttribute("Name",$row['company']);
  $newnode->setAttribute("address",$row['address']);
  $newnode->setAttribute("img",$row['logo']);
  $newnode->setAttribute("concrete",$row['concrete']);
  $newnode->setAttribute("steel",$row['steel']);
  $newnode->setAttribute("composite",$row['composite']);
  $newnode->setAttribute("Lat", $row['latitude']);
  $newnode->setAttribute("Lng", $row['longitude']);
}

echo $dom->saveXML();

?>
