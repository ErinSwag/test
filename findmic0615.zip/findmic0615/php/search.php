<?php          
	if(isset($_POST["submit"]) && $_POST["submit"] == "Search"){              
		$sname = $_POST["searchName"];              
		if($sname == ""){                  
			echo "<script>alert('请输入名称！'); history.go(-1);</script>";              
		}              
		else{ 
			// Opens a connection to a MySQL server
			define("DB_HOST","hkmicsupplier.sftp.wpengine.com");
			define("DB_USER","hkmicsupplier");
			define("DB_PASS","RwJavnX0h8EZYpanMNCI");
			define("DB_NAME","wp_hkmicsupplier");
			$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
			if (mysqli_connect_errno())
			{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
			} 

			// Select all the rows in the projects table

			$querys = "SELECT * FROM suppliers where Name = '$_POST[sname]' ";//需要模糊搜索就需要完成另一个功能（搜索下拉框）
			$queryp = "SELECT * FROM projects where Name = '$_POST[sname]' ";//需要模糊搜索就需要完成另一个功能（搜索下拉框）
			$results = mysqli_query($connection,$querys);
			$resultp = mysqli_query($connection,$queryp);
			if (!$results)
			{
				if(!$resultp){
					header("location:404.html");
				}
				else{
					$rowp = @mysqli_fetch_assoc($resultp)
					header("Location: /listp.php?name=".$rowp['Name']);
				}		
			}
			else{
				$rows = @mysqli_fetch_assoc($results)
				header("Location: /lists.php?name=".$rows['Name']);
			}
                       
		}        
	}          
	else{              
		echo "<script>alert('提交未成功！'); history.go(-1);</script>";          
	}            
?>
