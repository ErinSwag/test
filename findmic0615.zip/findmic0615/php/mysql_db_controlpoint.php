<?php

// Start XML file, create parent node

$dom = new DOMDocument("1.0");
$node = $dom->createElement("controlpoints");
$parnode = $dom->appendChild($node);

// Opens a connection to a MySQL server
define("DB_HOST","47.244.185.245");
define("DB_USER","root");
define("DB_PASS","Cicid2019");
define("DB_NAME","mic");
define("DB_PORT","3306");
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
if (mysqli_connect_error())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
} 

// Select all the rows in the projects table

$query = "SELECT * FROM controlpoints";
$result = mysqli_query($connection,$query);
if (!$result)
{
echo("Error description: " . mysqli_error($connection));
}

// Iterate through the rows, adding XML nodes for each

header("Content-type: text/xml");

while ($row = @mysqli_fetch_assoc($result)){
  // Add to XML document node
  $node = $dom->createElement("controlpoint");
  $newnode = $parnode->appendChild($node);
  $newnode->setAttribute("ControlPointID",$row['sn']);
  $newnode->setAttribute("Name",$row['name']);
  $newnode->setAttribute("Lat", $row['latitude']);
  $newnode->setAttribute("Lng", $row['longitude']);
  $newnode->setAttribute("OpeningTime", $row['opening_time']);
  $newnode->setAttribute("ClosingTime", $row['closing_time']);
  $newnode->setAttribute("WidthRestriction", $row['width_restriction']);
  $newnode->setAttribute("HeightRestriction", $row['height_restriction']);
}

echo $dom->saveXML();

?>
