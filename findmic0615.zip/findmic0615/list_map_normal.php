<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Find easily a doctor and book online an appointment">
	<meta name="author" content="Ansonika">
	<title>FindMiC: find projects and suppliers near you</title>

	<!-- Favicons-->
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">

	<!-- BASE CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/menu.css" rel="stylesheet">
	<link href="css/vendors.css" rel="stylesheet">
	<link href="css/icon_fonts/css/all_icons_min.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
	<link href="css/tables.css" rel="stylesheet">
    
	<!-- YOUR CUSTOM CSS -->
	<link href="css/custom.css" rel="stylesheet">
	
	<!-- Modernizr -->
	<script src="js/modernizr_tables.js"></script>
	<style type="text/css">
table.hovertable {
	font-family: verdana,arial,sans-serif;
	font-size:11px;
	color:#ffffff;
	border-width: 1px;
	border-color: #999999;
	border-collapse: collapse;
	margin-bottom:20px;
}
table.hovertable th {
	background-color:#3F4079;
	border-width: 1px;
	padding: 8px;
	border-style: solid;
	border-color: #a9c6c9;
	
}
table.hovertable tr {
	background-color:#e1e8ed;
}
table.hovertable td {
	border-width: 1px;
	padding: 8px;
	border-style: solid;
	border-color: #a9c6c9;
	color:#333333;
}
.content-left{
	padding-top:0px;
}
</style>
    <style>
        html,
        body {
            height: 100%;
        }
    </style>
	<style type="text/css">

 #menu{ background-color:#eee; width:600px; height:40px; margin:0 auto;}

 #test ul{ list-style:none;}

 #test ul li{ line-height:40px; text-align:center; position:relative; float:left;}

#test a{ text-decoration:none; color:#000; display:block; width:90px;}

 #test a:hover{ color:#FFF; background-color:#666;}

#test ul li ul li{ float:none;margin-top:2px; background-color:#eee; } 

#test ul li ul{width:90px; position:absolute;display:none;  }

#test ul li:hover ul{display:block;}

</style>
</head>

<body>
	
	<?php
		$url=$_SERVER["QUERY_STRING"];
		parse_str($url, $output);
		if($output!=null){
			if($output['latitude']&&$output['longitude']&&$output['typemap']){
			$lat1=trim($output['latitude']);
			$long1=trim($output['longitude']);
			$typemap=trim($output['typemap']);
		echo "<input type='text' id='lat1' value=".$lat1.">
			<input type='text' id='long1' value=".$long1.">
			<input type='text' id='typemap' value=".$typemap.">";
		}
		}
	?>
	<div class="layer"></div>
	<!-- Mobile menu overlay mask -->

	<div id="preloader">
		<div data-loader="circle-side"></div>
	</div>
	<!-- End Preload -->
    
    <header class="header_sticky">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div id="logo_home">
                            <h1><a href="index.html" title="FindMiC">FindMiC</a></h1>
                        </div>
                    </div>
                    <nav class="col-lg-9 col-6">
					<div>
                        <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="#0"><span>Menu mobile
						
						</span></a>
					</div>
					<div id="test">
                        <ul id="top_access">
                            <li><i class="pe-7s-user"></i>
							<div>
							<ul>
						<li><a href="middle.php">My Home Page</a></li>
						<li><a href="login.html">Login</a></li>
						<li><a href="javascript:void(0)" onclick="logout()">Logout</a></li>
						</ul>
							</div>
							</li>
							<script>
							$('i.pe-7s-user').hover(function(){
        $(this).find('ul').show();
    },function(){
        $(this).find('ul').hide();
    });
							</script>
                        </ul>
						</div>
                        <div class="main-menu">
                            <ul>
                                <li class="submenu">
                                    <a href="index.html" class="show-submenu">Home</a>
                                   
                                </li>
                                <li class="submenu">
                                    <a href="list_map_normal.php"  class="show-submenu">Database</a>
                                    
                                </li>
                                <li><a href="contacts.html">Contact Us</a></li>
                            </ul>
                        </div>
                        <!-- /main-menu -->
                    </nav>
                </div>
            </div>
        </header>
		<script>
						function logout(){
							setCookie("account_name","");
							setCookie("sn","");
							setCookie("type","");
							setCookie("company","");
							setCookie("password","");
							window.location.href="index.html";
						}
						
function setCookie(cname, cvalue, exdays) {

    var d = new Date();

    d.setTime(d.getTime() + (exdays*24*60*60*1000));

    var expires = "expires="+d.toUTCString();

    document.cookie = cname + "=" + cvalue + "; " + expires;

}
</script>
	<!-- /Header -->

	<div class="container-fluid full-height">
		<div class="row row-height">
			<div class="col-lg-5 content-left">
            <!-- /breadcrumb -->
	        <div class="margin_60_35" style="display: none">
					<div class="container">
						<div class="main_title" style="margin-bottom:20px">
							<h1>Supply Chain Scheme Comparison</h1>
						</div>
					</div>
					
					<div class="pricing-container cd-has-margins">
					<table id="compareTable" class="hovertable">
						<tr>
							<th></th>
							<th>Lok Ma Chau Control Point</th>
							<th>Shenzhen Bay Port</th>
							<th>Man Kam To Control Point</th>
							<th>Sha Tau Kok Control Point</th>
							
						</tr>
						<tr>
							<td>Distance</td>
							<td><div id="distance"></div></td>
							<td><div id="distance1"></div></td>
							<td><div id="distance2"></div></td>
							<td><div id="distance3"></div></td>
						</tr>
						<tr>
							<td>Time</td>
							<td><div id="wastetime"></div></td>
							<td><div id="wastetime1"></div></td>
							<td><div id="wastetime2"></div></td>
							<td><div id="wastetime3"></div></td>
						</tr>
					</table>
					
				</div>
				<!-- /pricing-container -->	
				</div>
				<!-- /margin_60_35 -->
				
					<!-- /filters -->
				<div class="tabs_styled_2">
					<form method="post" action="search_list.php">
						<div class="search_bar_wrapper">
							<div class="search_bar_list">
								<input type="text" class="form-control" placeholder="Ex. Suppliers or Projects..." id="key" name="key">
								<input type="submit" value="Search" id="btn">
							</div>
						</div>
					</form>
						<ul class="nav nav-tabs" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" id="general-tab" data-toggle="tab" href="#general" role="tab" aria-controls="general" aria-expanded="true">All</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="projects-tab" data-toggle="tab" href="#projects" role="tab" aria-controls="projects">Projects</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="suppliers-tab" data-toggle="tab" href="#suppliers" role="tab" aria-controls="suppliers">Suppliers</a>
							</li>
						</ul>
						<!--/nav-tabs -->
				<div class="tab-content">
					<div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
					<?php
					include_once("connect.php");
					$queryp = "SELECT * FROM project order by project_name asc";
					$resultp = mysqli_query($connection,$queryp);
					$rowp = @mysqli_fetch_assoc($resultp);
						if ($rowp=="")
						{
							echo "No Results";     
						}
						else{
							mysqli_data_seek($resultp,0);
							$i=1;
							 while($rowpp = $resultp->fetch_assoc()) {
								echo "<div class='strip_list'>
										<figure>
											<a href='list_project.php?sn=".$rowpp['sn']."'><img src='".$rowpp['image']."' alt=''></a>
										</figure>
										<small>Project</small>
										<h3>".$rowpp['project_name']."</h3>
										
										<ul>
											<li><a href='javascript:void(0)' onclick='panToP(".$rowpp['latitude'].",".$rowpp['longitude'].")'>View on Map</a></li>
											<li><a href='list_project.php?sn=".$rowpp['sn']."'>Find more</a></li>
										</ul>
									</div>";
								$i++;
							}											
						}
					$querys = "SELECT * FROM supplier order by company asc";
					$results = mysqli_query($connection,$querys);
					$rows = @mysqli_fetch_assoc($results);
						if ($rows=="")
						{
							echo "No Results";     
						}
						else{
							mysqli_data_seek($results,0);
							$i=1;
							 while($rowss = $results->fetch_assoc()) {
								echo "<div class='strip_list'>
										<a href='collect.php?sn=".$rowss['sn']."' class='wish_bt'></a>
										<figure>
											<a href='list_supplier.php?sn=".$rowss['sn']."'><img src='".$rowss['logo']."' alt=''></a>
										</figure>
										<small>Supplier</small>
										<h3>".$rowss['company']."</h3>
										
										<ul>
											<li><a href='javascript:void(0)' onclick='panTo(".$rowss['latitude'].",".$rowss['longitude'].")'>View on Map</a></li>
											<li><a href='list_supplier.php?sn=".$rowss['sn']."'>Projects</a></li>
											<li><a href='list_supplier.php?sn=".$rowss['sn']."'>Find more</a></li>
										</ul>
									</div>";
								$i++;
							}											
						}
				?>
				
					</div>
					
					<div class="tab-pane fade" id="projects" role="tabpanel" aria-labelledby="projects-tab">
					<?php
					include_once("connect.php");
					$querypp = "SELECT * FROM project order by project_name ASC Limit 5";
					$resultpp = mysqli_query($connection,$querypp);
					$rowppp = @mysqli_fetch_assoc($resultpp);
						if ($rowppp=="")
						{
							echo "No Results";     
						}
						else{
							mysqli_data_seek($resultpp,0);
							$i=1;
							 while($rowpppp = $resultpp->fetch_assoc()) {
								echo "<div class='strip_list'>
										<figure>
											<a href='list_project.php?sn=".$rowpppp['sn']."'><img src='".$rowpppp['image']."' alt=''></a>
										</figure>
										<small>Project</small>
										<h3>".$rowpppp['project_name']."</h3>
										
										<ul>
											<li><a href='javascript:void(0)' onclick='panToP(".$rowpppp['latitude'].",".$rowpppp['longitude'].")'>View on Map</a></li>
											<li><a href='list_project.php?sn=".$rowpppp['sn']."'>Find more</a></li>
										</ul>
									</div>";
								$i++;
							}											
						}	
				?>
				
				
				<p class="text-center add_top_30"><a href="#0"><strong>Load more</strong></a></p>
					</div>
					
					<div class="tab-pane fade" id="suppliers" role="tabpanel" aria-labelledby="suppliers-tab">
					<?php
					include_once("connect.php");
					$queryss = "SELECT * FROM supplier order by company ASC Limit 10";
					$resultss = mysqli_query($connection,$queryss);
					$rowsss = @mysqli_fetch_assoc($resultss);
						if ($rowsss=="")
						{
							echo "No Results";     
						}
						else{
							mysqli_data_seek($resultss,0);
							$i=1;
							 while($rowssss = $resultss->fetch_assoc()) {
								echo "<div class='strip_list'>
										<a href='collect.php?sn=".$rowssss['sn']."' class='wish_bt'></a>
										<figure>
											<a href='list_supplier.php?sn=".$rowssss['sn']."'><img src='".$rowssss['logo']."' alt=''></a>
										</figure>
										<small>Supplier</small>
										<h3>".$rowssss['company']."</h3>
										
										<ul>
											<li><a href='javascript:void(0)' onclick='panTo(".$rowssss['latitude'].",".$rowssss['longitude'].")'>View on Map</a></li>
											<li><a href='list_supplier.php?sn=".$rowssss['sn']."'>Projects</a></li>
											<li><a href='list_supplier.php?sn=".$rowssss['sn']."'>Find more</a></li>
										</ul>
									</div>";
								$i++;
							}											
						}	
				?>
				<div id="load" name="load">
				<p class="text-center add_top_30"><a href="javascript:void(0)" onclick="LoadMore()"><strong>Load more</strong></a></p>
				</div>
				<div id="load2" name="load2" hidden>
					
				<?php
					include_once("connect.php");
					$queryp2 = "SELECT * FROM supplier order by company ASC limit 10,20";
					$resultp2 = mysqli_query($connection,$queryp2);
					$rowp2 = @mysqli_fetch_assoc($resultp2);
						if ($rowp2=="")
						{
							echo "No Results";     
						}
						else{
							mysqli_data_seek($resultp2,0);
							$i=1;
							 while($rowpp2 = $resultp2->fetch_assoc()) {
								echo "<div class='strip_list'>
										<a href='collect.php?sn=".$rowpp2['sn']."' class='wish_bt'></a>
										<figure>
											<a href='list_supplier.php?sn=".$rowpp2['sn']."'><img src='".$rowpp2['logo']."' alt=''></a>
										</figure>
										<small>Supplier</small>
										<h3>".$rowpp2['company']."</h3>
										
										<ul>
											<li><a href='javascript:void(0)' onclick='panTo(".$rowpp2['latitude'].",".$rowpp2['longitude'].")'>View on Map</a></li>
											<li><a href='list_supplier.php?sn=".$rowpp2['sn']."'>Projects</a></li>
											<li><a href='list_supplier.php?sn=".$rowpp2['sn']."'>Find more</a></li>
										</ul>
									</div>";
								$i++;
							}
						}	
				?>
				</div>
					</div>
				</div>
				</div>
				
			</div>
			<!-- /content-left-->
			<script>
			function LoadMore(){
				let load=document.getElementById("load");
				load.parentNode.removeChild(load);
				let load2=document.getElementById("load2");
				load2.removeAttribute("hidden");
			}
			</script>
			<input type="hidden" id="lat" value="">
			<input type="hidden" id="lng" value="">
			<div class="col-lg-7 map-right">
				<div id="map_listing"></div>
				<!-- map-->
			</div>
			<!-- /map-right-->
			
		</div>
		<!-- /row-->
	</div>
	<!-- /container-fluid -->

	<!-- COMMON SCRIPTS -->
	<script src="js/jquery-2.2.4.min.js"></script>
	<script src="js/common_scripts.min.js"></script>
	<script src="assets/validate.js"></script>
	<script src="js/functions.js"></script>
    
    <!-- SPECIFIC SCRIPTS -->
    
    <script src="http://libs.baidu.com/jquery/1.9.0/jquery.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCvI1uy8W1WWeK5Or8Qq47QCPQX94dprXE&callback=initMap" async defer></script>
	<script src="js/map.js"></script>
	
    <script src="js/infobox.js"></script> 
    <script src="js/jquery.selectbox-0.2.js"></script>
	<script>
		$(".selectbox").selectbox();
	</script>
</body>

</html>
<script>
    $(window).load(function(){
        //$("#map [title='������� Google ��ͼ�ϲ鿴������']").hide(); 
        //$('.gm-style-cc').hide();
    });
</script>