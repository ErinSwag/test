﻿<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Find easily a doctor and book online an appointment">
	<meta name="author" content="Ansonika">
	<title>FindMiC: find projects and suppliers near you</title>

	<!-- Favicons-->
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">

	<!-- BASE CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/menu.css" rel="stylesheet">
	<link href="css/vendors.css" rel="stylesheet">
	<link href="css/icon_fonts/css/all_icons_min.css" rel="stylesheet">

	<!-- SPECIFIC CSS -->
	<link href="css/tables.css" rel="stylesheet">
    
	<!-- YOUR CUSTOM CSS -->
	<link href="css/custom.css" rel="stylesheet">
	
	<!-- Modernizr -->
	<script src="js/modernizr_tables.js"></script>
	
    <style>
        html,
        body {
            height: 100%;
        }
    </style>
	<style type="text/css">

*{ margin:0px; padding:0px;}

 #menu{ background-color:#eee; width:600px; height:40px; margin:0 auto;}

 #test ul{ list-style:none;}

 #test ul li{ line-height:40px; text-align:center; position:relative; float:left;}

#test a{ text-decoration:none; color:#000; display:block; width:90px;}

 #test a:hover{ color:#FFF; background-color:#666;}

#test ul li ul li{ float:none;margin-top:2px; background-color:#eee; } 

#test ul li ul{width:90px; position:absolute;display:none;  }

#test ul li:hover ul{display:block;}

</style>      
</head>

<body>

	<div class="layer"></div>
	<!-- Mobile menu overlay mask -->

	<div id="preloader">
		<div data-loader="circle-side"></div>
	</div>
	<!-- End Preload -->
    
    <header class="header_sticky">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div id="logo_home">
                            <h1><a href="index.html" title="FindMiC">FindMiC</a></h1>
                        </div>
                    </div>
                    <nav class="col-lg-9 col-6">
					<div>
                        <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="#0"><span>Menu mobile
						
						</span></a>
					</div>
					<div id="test">
                        <ul id="top_access">
                            <li><i class="pe-7s-user"></i>
							<div>
							<ul>
						<li><a href="middle.php">My Home Page</a></li>
						<li><a href="login.html">Login</a></li>
						<li><a href="javascript:void(0)" onclick="logout()">Logout</a></li>
						</ul>
							</div>
							</li>
							<script>
							$('i.pe-7s-user').hover(function(){
        $(this).find('ul').show();
    },function(){
        $(this).find('ul').hide();
    });
							</script>
                        </ul>
						</div>
                        <div class="main-menu">
                            <ul>
                                <li class="submenu">
                                    <a href="index.html" class="show-submenu">Home</a>
                                   
                                </li>
                                <li class="submenu">
                                    <a href="list_map_normal.php"  class="show-submenu">Database</a>
                                    
                                </li>
                                <li><a href="contacts.html">Contact Us</a></li>
                            </ul>
                        </div>
                        <!-- /main-menu -->
                    </nav>
                </div>
            </div>
        </header>
		<script>
						function logout(){
							setCookie("account_name","");
							setCookie("sn","");
							setCookie("type","");
							setCookie("company","");
							setCookie("password","");
							window.location.href="index.html";
						}
						
function setCookie(cname, cvalue, exdays) {

    var d = new Date();

    d.setTime(d.getTime() + (exdays*24*60*60*1000));

    var expires = "expires="+d.toUTCString();

    document.cookie = cname + "=" + cvalue + "; " + expires;

}
						</script>
	<!-- /Header -->

	<div class="container-fluid full-height">
		<div class="row row-height">
			<div class="col-lg-5 content-left">
            <!-- /breadcrumb -->
	        <div class="margin_60_35" style="display: none">
					<div class="container">
						<div class="main_title">
							<h1>Supply Chain Scheme Comparison</h1>
							<p>Version with monthly/year switcher</p>
						</div>
					</div>
					
					<div class="pricing-container cd-has-margins">
					<div class="pricing-switcher">
						<p class="fieldset">
							<input type="radio" name="duration-2" value="monthly" id="monthly-2" checked>
							<label for="monthly-2">Monthly</label>
							<input type="radio" name="duration-2" value="yearly" id="yearly-2">
							<label for="yearly-2">Yearly</label>
							<span class="switch"></span>
						</p>
					</div>
					<!--/pricing-switcher -->
					<ul class="pricing-list bounce-invert">
						<li>
							<ul class="pricing-wrapper">
								<li data-type="monthly" class="is-visible">
									<header class="pricing-header">
										<h2>Basic</h2>
			
										<div class="price">
											<span class="currency">$</span>
											<span class="price-value">30</span>
											<span class="price-duration">mo</span>
										</div>
									</header>
									<!-- /pricing-header -->
									<div class="pricing-body">
										<ul class="pricing-features">
											<li><em>One Time</em> Fee</li>
											<li><em>1</em> User</li>
											<li><em>Lifetime</em> Availability</li>
											<li><em>Non</em> Featured</li>
											<li><em>30 days</em> Listing</li>
											<li><em>24/7</em> Support</li>
										</ul>
									</div>
									<!-- /pricing-body -->
									<footer class="pricing-footer">
										<a class="select-plan" href="#0">Select</a>
									</footer>
								</li>
								<li data-type="yearly" class="is-hidden">
									<header class="pricing-header">
										<h2>Basic</h2>
			
										<div class="price">
											<span class="currency">$</span>
											<span class="price-value">320</span>
											<span class="price-duration">yr</span>
										</div>
									</header>
									<!-- /pricing-header -->
									<div class="pricing-body">
										<ul class="pricing-features">
											<li><em>One Time</em> Fee</li>
											<li><em>1</em> User</li>
											<li><em>Lifetime</em> Availability</li>
											<li><em>Non</em> Featured</li>
											<li><em>30 days</em> Listing</li>
											<li><em>24/7</em> Support</li>
										</ul>
									</div> 
									<!-- /pricing-body -->
									<footer class="pricing-footer">
										<a class="select-plan" href="#0">Select</a>
									</footer>
								</li>
							</ul>
							<!-- /pricing-wrapper -->
						</li>
						<li class="popular">
							<ul class="pricing-wrapper">
								<li data-type="monthly" class="is-visible">
									<header class="pricing-header">
										<h2>Popular</h2>
										<div class="price">
											<span class="currency">$</span>
											<span class="price-value">60</span>
											<span class="price-duration">mo</span>
										</div>
									</header>
									<!-- /pricing-header -->
									<div class="pricing-body">
										<ul class="pricing-features">
											<li><em>One Time</em> Fee</li>
											<li><em>3</em> User</li>
											<li><em>Lifetime</em> Availability</li>
											<li><em>Non</em> Featured</li>
											<li><em>30 days</em> Listing</li>
											<li><em>24/7</em> Support</li>
										</ul>
									</div>
									<!-- /pricing-body -->
									<footer class="pricing-footer">
										<a class="select-plan" href="#0">Select</a>
									</footer>
								</li>
								<li data-type="yearly" class="is-hidden">
									<header class="pricing-header">
										<h2>Popular</h2>
										<div class="price">
											<span class="currency">$</span>
											<span class="price-value">630</span>
											<span class="price-duration">yr</span>
										</div>
									</header>
									<!-- /pricing-header -->
									<div class="pricing-body">
										<ul class="pricing-features">
											<li><em>One Time</em> Fee</li>
											<li><em>3</em> User</li>
											<li><em>Lifetime</em> Availability</li>
											<li><em>Non</em> Featured</li>
											<li><em>30 days</em> Listing</li>
											<li><em>24/7</em> Support</li>
										</ul>
									</div>
									<!-- /pricing-body -->
									<footer class="pricing-footer">
										<a class="select-plan" href="#0">Select</a>
									</footer>
								</li>
							</ul>
							<!-- /cd-pricing-wrapper -->
						</li>
						<li>
							<ul class="pricing-wrapper">
								<li data-type="monthly" class="is-visible">
									<header class="pricing-header">
										<h2>Premier</h2>
										<div class="price">
											<span class="currency">$</span>
											<span class="price-value">90</span>
											<span class="price-duration">mo</span>
										</div>
									</header>
									<!-- /pricing-header -->
									<div class="pricing-body">
										<ul class="pricing-features">
											<li><em>One Time</em> Fee</li>
											<li><em>5</em> User</li>
											<li><em>Lifetime</em> Availability</li>
											<li><em>Non</em> Featured</li>
											<li><em>30 days</em> Listing</li>
											<li><em>24/7</em> Support</li>
										</ul>
									</div>
									<!-- /pricing-body -->
									<footer class="pricing-footer">
										<a class="select-plan" href="#0">Select</a>
									</footer>
								</li>
								<li data-type="yearly" class="is-hidden">
									<header class="pricing-header">
										<h2>Premier</h2>
			
										<div class="price">
											<span class="currency">$</span>
											<span class="price-value">950</span>
											<span class="price-duration">yr</span>
										</div>
									</header>
									<!-- /pricing-header -->
									<div class="pricing-body">
										<ul class="pricing-features">
											<li><em>One Time</em> Fee</li>
											<li><em>5</em> User</li>
											<li><em>Lifetime</em> Availability</li>
											<li><em>Non</em> Featured</li>
											<li><em>30 days</em> Listing</li>
											<li><em>24/7</em> Support</li>
										</ul>
									</div>
									<!-- /pricing-body -->
									<footer class="pricing-footer">
										<a class="select-plan" href="#0">Select</a>
									</footer>
								</li>
							</ul>
							<!-- /pricing-wrapper -->
						</li>
					</ul>
					<!-- /pricing-list -->
				</div>
				<!-- /pricing-container -->	
				</div>
				<!-- /margin_60_35 -->
				<form>
					<div class="search_bar_wrapper">
						<div class="search_bar_list">
							<input type="text" class="form-control" placeholder="Ex. Suppliers or Projects...">
							<input type="submit" value="Search">
						</div>
					</div>
					<div class="filters_listing map_listing">
						<ul class="clearfix">
							<li>
								<h6>Type</h6>
								<div class="switch-field">
									<input type="radio" id="all" name="type_patient" value="all" checked>
									<label for="all">All</label>
									<input type="radio" id="doctors" name="type_patient" value="doctors">
									<label for="doctors">Projects</label>
									<input type="radio" id="clinics" name="type_patient" value="clinics">
									<label for="clinics">Suppliers</label>
								</div>
							</li>
						</ul>
					</div>
					<!-- /filters -->
				</form>
				<?php
					include_once("connect.php");
					$queryp = "SELECT * FROM project";
					$resultp = mysqli_query($connection,$queryp);
					$rowp = @mysqli_fetch_assoc($resultp);
						if ($rowp=="")
						{
							echo "No Results";     
						}
						else{
							mysqli_data_seek($resultp,0);
							$i=1;
							 while($rowpp = $resultp->fetch_assoc()) {
								echo "<div class='strip_list'>
										<figure>
											<a href='list_project.php?sn=".$rowpp['sn']."'><img src='".$rowpp['image']."' alt=''></a>
										</figure>
										<small>Project</small>
										<h3>".$rowpp['project_name']."</h3>
										<span class='rating'><i class='icon_star voted'></i><i class='icon_star voted'></i><i class='icon_star voted'></i><i class='icon_star'></i><i class='icon_star'></i> <small>(145)</small></span>
										<ul>
											<li><a href='test.html'>View on Map</a></li>
											<li><a href='list_project.php?sn=".$rowpp['sn']."'>Find more</a></li>
										</ul>
									</div>";
								$i++;
							}											
						}	
				?>
				
				
				<p class="text-center add_top_30"><a href="#0"><strong>Load more</strong></a></p>
			</div>
			<!-- /content-left-->

			<div class="col-lg-7 map-right">
				<div id="map_listing"></div>
				<!-- map-->
			</div>
			<!-- /map-right-->
			
		</div>
		<!-- /row-->
	</div>
	<!-- /container-fluid -->

	<!-- COMMON SCRIPTS -->
	<script src="js/jquery-2.2.4.min.js"></script>
	<script src="js/common_scripts.min.js"></script>
	<script src="assets/validate.js"></script>
	<script src="js/functions.js"></script>
    
    
    <!-- SPECIFIC SCRIPTS -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCvI1uy8W1WWeK5Or8Qq47QCPQX94dprXE&callback=initMap"  async defer>
    </script>
    <script src="js/map_listing.js"></script>
    <script src="js/infobox.js"></script> 
    <script src="js/jquery.selectbox-0.2.js"></script>
	<script>
		$(".selectbox").selectbox();
	</script>


</body>

</html>
