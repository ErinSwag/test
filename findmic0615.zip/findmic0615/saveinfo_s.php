<?php
	if(!isset($_COOKIE["account_name"])){
		echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please login!"."\"".")".";"."</script>";
        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
		
	}
		if($_FILES["upfile"]["error"])
{
    echo $_FILES["upfile"]["error"];    
}
else
{
    //没有出错
    //加限制条件
    //判断上传文件类型为png或jpg且大小不超过1024000B
    if(($_FILES["upfile"]["type"]=="image/png"||$_FILES["upfile"]["type"]=="image/jpeg")&&$_FILES["upfile"]["size"]<1024000)
    {
            //防止文件名重复
            $filename ="img/suppliers/".time().$_FILES["upfile"]["name"];
            //转码，把utf-8转成gb2312,返回转换后的字符串， 或者在失败时返回 FALSE。
            $filename =iconv("UTF-8","gb2312",$filename);
             //检查文件或目录是否存在
            if(file_exists($filename))
            {
                echo"该文件已存在";
            }
            else
            {  
                //保存文件,   move_uploaded_file 将上传的文件移动到新位置  
                move_uploaded_file($_FILES["upfile"]["tmp_name"],$filename);//将临时地址移动到指定地址    
            }        
    }
    else
    {
        echo"文件类型不对";
    }
}
	// Opens a connection to a MySQL server
	include_once("connect.php");
	$account_name=addslashes($_POST["account_name"]);
	$sn=$_COOKIE["sn"];
	$email=addslashes($_POST["email"]);
	$phone=addslashes($_POST["phone"]);
	$address=addslashes($_POST["address"]);
	$statement=addslashes($_POST["statement"]);
	 // Select all the rows in the projects table
		$querys = "update supplier SET account_name='$account_name', contact_email='$email', contact_phone='$phone', address='$address', statement='$statement',image='$filename' WHERE supplier.sn='$sn'";
		$results = mysqli_query($connection,$querys);
		if ($results=="")
		{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Save Failure! Please add again"."\"".")".";"."</script>";
			echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."info_supplier.php"."\""."</script>";   
		}
		else{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Save Success!"."\"".")".";"."</script>";
			header("location:info_supplier.php");
		}
		
		$concrete=null;
	$steel=null,
	$composite=null;
		$sta = isset($_POST['sta'])? $_POST['sta'] : '';
		foreach($sta as $val) {        
			if($val=='concrete'){
				$concrete=$val;
			}else if($val=='steel'){
				$steel=$val;
			}else if($val=='composite'){
				$composite=$val;
			}     
		} 
		$queryp = "update structure_type,supplier SET structure_type.concrete='$concrete',structure_type.steel='$steel',structure_type.composite='$composite' WHERE supplier.sn='$sn' and supplier.structure_type=structure_type.sn";
		$resultp = mysqli_query($connection,$queryp);
		if ($resultp=="")
		{
			echo "<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Save Failure! Please add again"."\"".")".";"."</script>";
			echo "<script type="."\""."text/javascript"."\"".">"."window.location="."\""."index.html"."\""."</script>";   
		}
		else{
			echo "<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Save Success!"."\"".")".";"."</script>";
			echo "<script type="."\""."text/javascript"."\"".">"."window.location="."\""."info_supplier.php"."\""."</script>"; 
		}
		
		$housing_residential=null;
	$accommodation=null;
	$school=null;
	$office=null;
	$health_services_building=null;
	$hotels=null;
	$retail=null;
	$factories=null;
	$canteens=null;
	$sports_center_dance_studios=null;
	$mobile_unites_for_events=null;
	$storage=null;
	$laboratories=null;
		$bta = isset($_POST['bta'])? $_POST['bta'] : '';
		foreach($bta as $val) {        
			if($val=='housing_residential'){
				$housing_residential=$val;
			}else if($val=='accommodation'){
				$accommodation=$val;
			}else if($val=='school'){
				$school=$val;
			}else if($val=='office'){
				$office=$val;
			}else if($val=='health_services_building'){
				$health_services_building=$val;
			}else if($val=='hotels'){
				$hotels=$val;
			}else if($val=='retail'){
				$retail=$val;
			}else if($val=='factories'){
				$factories=$val;
			}else if($val=='canteens'){
				$canteens=$val;
			}else if($val=='laboratories'){
				$laboratories=$val;
			}else if($val=='sports_center_dance_studios'){
				$sports_center_dance_studios=$val;
			}else if($val=='mobile_unites_for_events'){
				$mobile_unites_for_events=$val;
			}else if($val=='storage'){
				$storage=$val;
			}     
		} 
		$querypp = "update building_type,supplier SET building_type.housing_residential='$housing_residential',building_type.accommodation='$accommodation',building_type.school='$school',building_type.office='$office',building_type.health_services_building='$health_services_building',building_type.hotels='$hotels',building_type.retail='$retail',building_type.factories='$factories',building_type.canteens='$canteens',building_type.laboratories='$laboratories',building_type.sports_center_dance_studios='$sports_center_dance_studios',building_type.mobile_unites_for_events='$mobile_unites_for_events',building_type.storage='$storage' WHERE supplier.sn='$sn' and supplier.building_type=building_type.sn";
		$resultpp = mysqli_query($connection,$querypp);
		if ($resultpp=="")
		{
			echo "<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Save Failure! Please add again"."\"".")".";"."</script>";
			echo "<script type="."\""."text/javascript"."\"".">"."window.location="."\""."index.html"."\""."</script>";   
		}
		else{
			echo "<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Save Success!"."\"".")".";"."</script>";
			echo "<script type="."\""."text/javascript"."\"".">"."window.location="."\""."info_supplier.php"."\""."</script>"; 
		}
	                      
	
?>
