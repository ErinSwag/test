﻿<?php  
	header("Content-Type: text/html;charset=utf-8");
	define("DB_HOST","47.244.185.245");
	define("DB_USER","root");
	define("DB_PASS","Cicid2019");
	define("DB_NAME","mic");
	define("DB_PORT","3306");
	$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);
	if (mysqli_connect_error())
	{
	echo "Failed to connect to MySQL: " .mysqli_connect_error();
	}
?>