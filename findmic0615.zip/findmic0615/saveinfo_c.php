<?php
	if(!isset($_COOKIE["account_name"])){
		echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please login!"."\"".")".";"."</script>";
        echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
		
	}
	//var_dump($_FILES["file"]);
//array(5) { ["name"]=> string(17) "56e79ea2e1418.jpg" ["type"]=> string(10) "image/jpeg" ["tmp_name"]=> string(43) "C:\Users\asus\AppData\Local\Temp\phpD07.tmp" ["error"]=> int(0) ["size"]=> int(454445) } 
	if($_FILES["upfile"]["error"])
{
    echo $_FILES["upfile"]["error"];    
}
else
{
    //没有出错
    //加限制条件
    //判断上传文件类型为png或jpg且大小不超过1024000B
    if(($_FILES["upfile"]["type"]=="image/png"||$_FILES["upfile"]["type"]=="image/jpeg")&&$_FILES["upfile"]["size"]<1024000)
    {
            //防止文件名重复
            $filename ="img/customer/".time().$_FILES["upfile"]["name"];
            //转码，把utf-8转成gb2312,返回转换后的字符串， 或者在失败时返回 FALSE。
            $filename =iconv("UTF-8","gb2312",$filename);
             //检查文件或目录是否存在
            if(file_exists($filename))
            {
                echo"该文件已存在";
            }
            else
            {  
                //保存文件,   move_uploaded_file 将上传的文件移动到新位置  
                move_uploaded_file($_FILES["upfile"]["tmp_name"],$filename);//将临时地址移动到指定地址    
            }        
    }
    else
    {
        echo"文件类型不对";
    }
}
	// Opens a connection to a MySQL server
	include_once("connect.php");
	$account_name=addslashes($_POST["account_name"]);
	$sn=$_COOKIE["sn"];
	$email=addslashes($_POST["email"]);
	$phone=addslashes($_POST["phone"]);
	$address=addslashes($_POST["address"]);
	 // Select all the rows in the projects table
		$querys = "update customer SET account_name='$account_name', email='$email', phone='$phone', address='$address', image='$filename' WHERE customer.sn='$sn'";
		$results = mysqli_query($connection,$querys);
		if ($results=="")
		{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Save Failure! Please add again"."\"".")".";"."</script>";
			//echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."index.html"."\""."</script>";   
		}
		else{
			echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Save Success!"."\"".")".";"."</script>";
			//header("location:info_customer.php");
		}
		
?>