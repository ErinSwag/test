<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Find easily a doctor and book online an appointment">
	<meta name="author" content="Ansonika">
	<title>FINDOCTOR - Find easily a doctor and book online an appointment</title>

	<!-- Favicons-->
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" type="image/x-icon" href="img/apple-touch-icon-57x57-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img/apple-touch-icon-72x72-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img/apple-touch-icon-114x114-precomposed.png">
	<link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img/apple-touch-icon-144x144-precomposed.png">

	<!-- BASE CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link href="css/menu.css" rel="stylesheet">
	<link href="css/vendors.css" rel="stylesheet">
	<link href="css/icon_fonts/css/all_icons_min.css" rel="stylesheet">
   
    <!-- SPECIFIC CSS -->
    <link href="css/date_picker.css" rel="stylesheet">
    
	<!-- YOUR CUSTOM CSS -->
	<link href="css/custom.css" rel="stylesheet">
	<style type="text/css">

*{ margin:0px; padding:0px;}

 #menu{ background-color:#eee; width:600px; height:40px; margin:0 auto;}

 #test ul{ list-style:none;}

 #test ul li{ line-height:40px; text-align:center; position:relative; float:left;}

#test a{ text-decoration:none; color:#000; display:block; width:90px;}

 #test a:hover{ color:#FFF; background-color:#666;}

#test ul li ul li{ float:none;margin-top:2px; background-color:#eee; } 

#test ul li ul{width:90px; position:absolute;display:none;  }

#test ul li:hover ul{display:block;}

</style>	
</head>

<body>

	<div class="layer"></div>
	<!-- Mobile menu overlay mask -->

	<div id="preloader">
		<div data-loader="circle-side"></div>
	</div>
	<!-- End Preload -->
    
	<header class="header_sticky">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div id="logo_home">
                            <h1><a href="index.html" title="FindMiC">FindMiC</a></h1>
                        </div>
                    </div>
                    <nav class="col-lg-9 col-6">
					<div>
                        <a class="cmn-toggle-switch cmn-toggle-switch__htx open_close" href="#0"><span>Menu mobile
						
						</span></a>
					</div>
					<div id="test">
                        <ul id="top_access">
                            <li><i class="pe-7s-user"></i>
							<div>
							<ul>
						<li><a href="middle.php">My Home Page</a></li>
						<li><a href="login.html">Login</a></li>
						<li><a href="javascript:void(0)" onclick="logout()">Logout</a></li>
						</ul>
							</div>
							</li>
							<script>
							$('i.pe-7s-user').hover(function(){
        $(this).find('ul').show();
    },function(){
        $(this).find('ul').hide();
    });
							</script>
                        </ul>
						</div>
                        <div class="main-menu">
                            <ul>
                                <li class="submenu">
                                    <a href="index.html" class="show-submenu">Home</a>
                                   
                                </li>
                                <li class="submenu">
                                    <a href="list_map_normal.php"  class="show-submenu">Database</a>
                                    
                                </li>
                                <li><a href="contacts.html">Contact Us</a></li>
                            </ul>
                        </div>
                        <!-- /main-menu -->
                    </nav>
                </div>
            </div>
        </header>
		<script>
						function logout(){
							setCookie("account_name","");
							setCookie("sn","");
							setCookie("type","");
							setCookie("company","");
							setCookie("password","");
							window.location.href="index.html";
						}
						
function setCookie(cname, cvalue, exdays) {

    var d = new Date();

    d.setTime(d.getTime() + (exdays*24*60*60*1000));

    var expires = "expires="+d.toUTCString();

    document.cookie = cname + "=" + cvalue + "; " + expires;

}
						</script>
	<!-- /Header -->
	
	<main>
		<div id="breadcrumb">
			<div class="container">
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="#">Account Information</a></li>
				</ul>
			</div>
		</div>
		<!-- /breadcrumb -->
		
		<div class="container margin_60">
			<div class="row">
				<?php 
					if(!isset($_COOKIE["account_name"])){
						echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please login!"."\"".")".";"."</script>";
						echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
					}else{
						$account_name=$_COOKIE["account_name"];
						include_once("connect.php");
						$querys = "SELECT supplier.statement,supplier.image AS image,supplier.contact_email AS email,supplier.latitude,supplier.longitude,supplier.logo, supplier.account_name,supplier.company, supplier.address, supplier.contact_phone AS phone, structure_type.concrete AS concrete, structure_type.steel AS steel, structure_type.composite AS composite, building_type.housing_residential AS housing_residential, building_type.accommodation AS accommodation, building_type.school AS school, building_type.office AS office, building_type.health_services_building AS health_services_building, building_type.hotels AS hotels, building_type.retail AS retail, building_type.factories AS factories, building_type.canteens AS canteens, building_type.mobile_unites_for_events AS mobile_unites_for_events, building_type.sports_center_dance_studios AS sports_center_dance_studios, building_type.storage AS storage, building_type.laboratories AS laboratories FROM supplier,structure_type, building_type where supplier.account_name='$account_name' and supplier.structure_type=structure_type.sn and supplier.building_type=building_type.sn";
						$results = mysqli_query($connection,$querys);
						$rows = @mysqli_fetch_assoc($results);
						if ($rows=="")
							{
								echo "No Results";     
						}else{
							mysqli_data_seek($results,0);
							$row=$results->fetch_assoc();
							
						}
					}
					
				?>
				<aside class="col-xl-3 col-lg-4" id="sidebar">
					<div class="box_profile">
						<figure>
						<?php
							echo "<img src='".$row['logo']."' alt='' class='img-fluid'>";
						?>
						</figure>
						<h1><?php echo $row["company"]?></h1>
						<span class="rating">
							<i class="icon_star voted"></i>
							<i class="icon_star voted"></i>
							<i class="icon_star voted"></i>
							<i class="icon_star voted"></i>
							<i class="icon_star  voted"></i>
							<small>(145)</small>
							<a href="badges.html" data-toggle="tooltip" data-placement="top" data-original-title="Badge Level" class="badge_list_1"><img src="img/badges/badge_1.svg" width="15" height="15" alt=""></a>
						</span>
						<ul class="statistic">
							<li>854 Views</li>
							<li>124 Patients</li>
						</ul>
						<ul class="contacts">
							<li><h6>Address</h6><?php echo $row["address"]?></li>
							<li><h6>Phone</h6><a href="tel://000434323342"><?php echo $row["phone"]?></a></li>
						</ul>
						<div class="text-center">
						<?php
							echo "<a href='list_map_normal.php?latitude=".$row['latitude']."&longitude=".$row["longitude"]."&typemap=s' class='btn_1 outline' target='_blank'>";
						?>
						</i> View on map</a></div>
						<p class="text-center"><a href="javascript:void(0)" class="btn_1 medium" onclick="logout()">Logout</a></p>
						<script>
						function logout(){
							setCookie("account_name","");
							setCookie("sn","");
							setCookie("type","");
							setCookie("company","");
							setCookie("password","");
							window.location.href="index.html";
						}
						
function setCookie(cname, cvalue, exdays) {

    var d = new Date();

    d.setTime(d.getTime() + (exdays*24*60*60*1000));

    var expires = "expires="+d.toUTCString();

    document.cookie = cname + "=" + cvalue + "; " + expires;

}
						</script>
					</div>
				</aside>
				<!-- /asdide -->
				
				<div class="col-xl-9 col-lg-8">

					<div class="tabs_styled_2">
						<ul class="nav nav-tabs" role="tablist">
							<li class="nav-item">
								<a class="nav-link active" id="general-tab" data-toggle="tab" href="#general" role="tab" aria-controls="general" aria-expanded="true">Account information</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" id="reviews-tab" data-toggle="tab" href="#reviews" role="tab" aria-controls="reviews">Existing Project</a>
							</li>
						</ul>
						<!--/nav-tabs -->

					<div class="tab-content">

							<div class="tab-pane fade" id="book" role="tabpanel" aria-labelledby="book-tab">

								<div class="indent_title_in">
								
									<h3>Company Introduction</h3><i class="icon-edit"></i>
								</div>
								<div class="wrapper_indent">
									<p>ModuleCo offers fast-track, design and build, fully-fitted permanent healthcare buildings, produced using state of the art modular construction techniques.</p>

    <p>Robust, high quality and sophisticated they enable the rapid provision of essential healthcare facilities where they are needed most to ease capacity pressure within the NHS and private healthcare organisations.</p>
    <p>A ModuleCo facility offers significant benefits compared to traditional construction methods:</p>

    <p>Programme times are reduced by more than 50%.
    On-site programme times are shortened by more than 50%, reducing on-site disruption and environmental impact
    Precision assembly carried out in a clean, controlled, factory environment guaranteeing a greater build quality than that achieved through traditional construction methods.
    Process-driven construction methodology enabling programme and budget certainty.
    Flexibility for future expansion by increasing the building footprint or providing additional storeys.</p>

    <p>Our modular construction techniques do not compromise on specification or build quality and our facilities are:</p>

    <p>Designed with a structural life in excess of 60 years
    Fully compliant with UK building regulations and NHS HBN and HTM standards
    Able to match existing structures through the use of traditional building cladding systems</p>

								</div>
								<!-- /wrapper indent -->
								
								<hr>
								<div class="text-right">
							     </div>
								<div class="indent_title_in">
									<i class="pe-7s-home"></i>
									<h3>Building Type</h3>
									
								</div>
								<p></p>
								<div class="wrapper_indent">
									<p>Our portable buildings are available in a range of sizes and internal layouts to meet your requirements. They are capable of double stacking or being linked together for a wide range of uses. We can supply new or re-furbished portable buildings. You can buy or hire our portable buildings, giving you flexibility if you need to protect your capital. We can deliver throughout the UK and have prices to suit all budgets.</p>
									<h6>Reivew  Table</h6>
				
									<ul class="treatments clearfix">
										<li>
											<div class="checkbox">
												<i class="icon-edit"></i><strong>Housing/Residential </strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
										<li>
											<div class="checkbox">
												<i class="icon-edit"></i><strong>Accomodation </strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>										</li>
										<li>
											<div class="checkbox">
												<i class="icon-edit"></i><strong>School</strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
										<li>
											<div class="checkbox">
												<i class="icon-edit"></i><strong>Office</strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
										<li>
											<div class="checkbox">
												<i class="icon-edit"></i><strong>Health Services </strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
										<li>
											<div class="checkbox">
												<div class="checkbox">
												<i class="icon-edit"></i><strong>Hospital & Healthe center</strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
											</div>
										</li>
										<li>
											<div class="checkbox">
												<i class="icon-edit"></i><strong> Hotels </strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
										<li>
											<div class="checkbox">
												<i class="icon-edit"></i><strong> Retail </strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
										<li>
											<div class="checkbox">
												<i class="icon-edit"></i><strong> Factories </strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
										<li>
											<div class="checkbox">
												<i class="icon-edit"></i><strong> Canteens </strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
										<li>
											<div class="checkbox">
												<i class="icon-edit"></i><strong> Sports Center & Dance Studios </strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
								
										
										<li>
											<div class="checkbox">
											<i class="icon-edit"></i><strong> Storage </strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
									
										<li>
											<div class="checkbox">
												<i class="icon-edit"></i><strong> Mobile Unites For Events </strong>
												<label for="visit1" class="css-label"><strong> </strong></label>
											</div>
										</li>
									</ul>
								</div>
								<!--  End wrapper indent -->				
								<hr>
								<p class="text-center"><a href="booking-page.html" class="btn_1 medium">Edit</a></p>
							</div>
							<!-- /tab_1 -->
							
							<div class="tab-pane fade show active" id="general" role="tabpanel" aria-labelledby="general-tab">
							     <div class="indent_title_in">
									<i class="pe-7s-user"></i>
									<h3>General Information</h3>
								</div>
								<form action="saveinfo_s.php" method="post" enctype="multipart/form-data">
								<div class="wrapper_indent">
									<ul class="treatments clearfix">
									<li style="height: 200px;">
											<div class="checkbox">
												<i class="icon-edit"></i>
												<strong>Image</strong>
												<br>
												<div id="divPreview">
											<img id="imgHeadPhoto" src="<?php echo $row['image']; ?>" style="width: 160px; height: 170px; border: solid 1px #d2e2e2;" alt="" />
										</div>
										<div id="uploadimg" style="display: none">
												<input type="file" name="upfile" id="upfile" onchange="PreviewImage(this,'imgHeadPhoto','divPreview');" size="20">
												</div>
											</div>
										</li>
										<li style="height: 80px;">
											<div class="checkbox">
												<i class="icon-edit"></i>			
												<strong>Account Name</strong>
												<br>
												<label for="visit1" class="css-label"><strong><?php echo"<input id='account_name' name='account_name' type='text' value='".$row['account_name']."' class='form-control' readonly='readonly'>"; 
												?> </strong></label>
											</div>										
										</li>
									
										<li style="height: 80px;">
											<div class="checkbox">
													<i class="icon-edit"></i>
												<strong>Phone</strong>
											
												<br>
												<label for="visit1" class="css-label"><strong><?php echo"<input id='phone' name='phone' type='text' value='".$row['phone']."' class='form-control' readonly='readonly'>"; 
												?> </strong></label>
											</div>
										</li>
										<li style="height: 80px;">
											<div class="checkbox">
												<i class="icon-edit"></i>
												<strong>Email</strong>
												<br>
												<label for="visit1" class="css-label"><strong><?php echo"<input id='email' name='email' type='text' type='text' value='".$row['email']."' class='form-control' readonly='readonly'>"; 
												?> </strong></label>
											</div>
										</li>
										<li style="height: 80px;">
											<div class="checkbox">
												<i class="icon-edit"></i>
												<strong>Address</strong>
												<br>
												<label for="visit1" class="css-label"><strong><?php echo"<input id='address' name='address' type='text' type='text' value='".$row['address']."' class='form-control' readonly='readonly'>"; 
												?> </strong></label>
											</div>
										</li>
										<div id="new_st" name="new_st" style="display:none">
										<strong>Plese Select Structure Type</strong>
									<ul class="treatments clearfix">
										<li>
											<div class="checkbox">
												<input type="checkbox" id="sta[]" name="sta[]" value="concrete">&nbsp;&nbsp;Concrete
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" id="sta[]" name="sta[]" value="steel">&nbsp;&nbsp;Steel
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" id="sta[]" name="sta[]" value="composite">&nbsp;&nbsp;Composite
											</div>
										</li>
										
									</ul>
									</div>
										<div id="st" name="st">
										<li style="height: 80px;">
										
											<div class="checkbox">
												<i class="icon-edit"></i>
												<strong>Structure Type</strong>
												<ul class="bullets">
										<strong><?php echo $row['concrete']?></strong>
										<strong><?php echo $row['steel']?></strong>
										<strong><?php echo $row['composite']?></strong>
										</ul>
										</div>	
										</li>
										
										</div>
											<div id="new_bt" name="new_bt" style="display:none">
										<strong>Plese Select Building Type</strong>
									<ul class="treatments clearfix">
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="housing_residential">&nbsp;&nbsp;housing/residential
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="accommodation">&nbsp;&nbsp;accommodation
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="school">&nbsp;&nbsp;school
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="office">&nbsp;&nbsp;office
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="health_services_building">&nbsp;&nbsp;health services building
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="hotels">&nbsp;&nbsp;hotels
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="retail">&nbsp;&nbsp;retail
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="factories">&nbsp;&nbsp;factories
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="canteens">&nbsp;&nbsp;canteens
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="sports_center_dance_studios">&nbsp;&nbsp;sports center dance studios
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="mobile_unites_for_events">&nbsp;&nbsp;mobile unites for events
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="storage">&nbsp;&nbsp;storage
											</div>
										</li>
										<li>
											<div class="checkbox">
												<input type="checkbox" name="bta[]" value="laboratories">&nbsp;&nbsp;laboratories
											</div>
										</li>
									</ul>
									</div>
									<div id="bt" name="bt">
										<li style="height: 80px;">
											<div class="checkbox">
												<i class="icon-edit"></i>
												<strong>Building Type</strong>
												<ul class="bullets">
										<strong><?php echo $row['housing_residential']?></strong>
										
										<strong><?php echo $row['accommodation']?></strong>
										
										<strong><?php echo $row['school']?></strong>
										
										<strong><?php echo $row['office']?></strong>
										
										<strong><?php echo $row['health_services_building']?></strong>
										
										<strong><?php echo $row['hotels']?></strong>
										
										<strong><?php echo $row['retail']?></strong>
										
										<strong><?php echo $row['factories']?></strong>
										
										<strong><?php echo $row['canteens']?></strong>
										
										<strong><?php echo $row['mobile_unites_for_events']?></strong>
										
										<strong><?php echo $row['sports_center_dance_studios']?></strong>
										
										<strong><?php echo $row['storage']?></strong>
										
										<strong><?php echo $row['laboratories']?></strong>
										
									</ul>
									</div>
										</li>
										</div>
										<li style="height: 200px;">
											<div class="checkbox">
												<i class="icon-edit"></i>
												<strong>Statement</strong>
												<br>
												<label for="visit1" class="css-label"><strong><?php echo"<input id='statement' name='statement' type='text' value='".$row['statement']."' class='form-control' readonly='readonly'>"; 
												?> </strong></label>
											</div>
										</li>
									</ul>
									<div id="editbutton" name="editbutton">
									<p class="text-center"><a href="javascript:void(0)" class="btn_1 medium" onclick="edit()">Edit</a></p>
									</div>
									<div class="form-group text-center add_top_30" id="savebutton" name="savebutton" style="display: none">
										<input class="btn_1" type="submit" value="Save" id="btn_add">
									</div>
								</div>
								</form>
								<!--  End wrapper indent -->
								<script>
								function edit(){
									document.getElementById("account_name").readOnly=false;
									document.getElementById("email").readOnly=false;
									document.getElementById("phone").readOnly=false;
									document.getElementById("address").readOnly=false;
									document.getElementById("statement").readOnly=false;
									document.getElementById("bt").style.display="none";
									document.getElementById("st").style.display="none";
									document.getElementById("new_bt").style.display="";
									document.getElementById("new_st").style.display="";
									document.getElementById("editbutton").style.display="none";
									document.getElementById("savebutton").style.display="";
									document.getElementById("uploadimg").style.display="";
									
								}
								</script>
							</div>
							<!-- /tab_2 -->
							
							<div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab">
								<div class="reviews-container">
								<?php 
										if(!isset($_COOKIE["account_name"])){
											echo"<script type="."\""."text/javascript"."\"".">"."window.alert"."("."\""."Please login!"."\"".")".";"."</script>";
											echo"<script type="."\""."text/javascript"."\"".">"."window.location="."\""."login.html"."\""."</script>";
										}else{
											$account_name=$_COOKIE["account_name"];
											include_once("connect.php");
											$queryn = "SELECT project.project_name AS project_name, project.beginning_date AS beginning_date, project.completion_date AS completion_date, project.sn AS sn, project.image AS image FROM supplier,project where supplier.account_name='$account_name' and supplier.company=project.module_contractor";
											$resultn = mysqli_query($connection,$queryn);
											$rown = @mysqli_fetch_assoc($resultn);
											if ($rown=="")
											{
												echo "No Results";     
											}
											else{
												mysqli_data_seek($resultn,0);
												$i=1;
												while($rownn = $resultn->fetch_assoc()) {
													echo '<div class="row" id="2_div">
															<div class="col-md-4">
															<img src="'.$rownn["image"].'" alt="" class="img-fluid">
															</div>
															<div class="rev-content col-md-8">
																<div class="rev-info">
																	<div class="indent_title_in">
																	<i class="pe-7s-note2"></i> 
																	<span class="italic"><h3>'.$rownn["project_name"].'</h3></span>
																	</div>
																	
																</div>

																<div class="row">
																	<div class="col-lg-12">
																		<ul class="bullets">
																			<li>Start Date:  '.$rownn["beginning_date"].'</li>
																			<li>Completat Date: '.$rownn["completion_date"].'</li>
																		</ul>
																	<div class="text-right">
																	<a href="update_project.php?sn='.$rownn["sn"].'" class="btn_1 outline" target="_blank"> <i class=" icon-folder-open"></i>Update Project</a>
																		<a href="list_project.php?sn='.$rownn["sn"].'" class="btn_1 outline" target="_blank"> <i class=" icon-folder-open"></i>Project Details </a>
																	<p></p> 
																	</div>
																	</div>
																</div>
															</div>
														  </div>
														<hr>';
													$i++;
												}											
											}
										}
									?>
								<p class="text-center"><a href="add_s_project.html" class="btn_1 medium">Add Project</a></p>
									
								</div>
					<!-- /tabs_styled -->
							</div>
				<!-- /col -->
					</div>
					<!-- /content -->
					</div>
				</div>
			</div>
		</div>		
		<!-- /container -->
	</main>
	<!-- /main -->
	
	<footer>
            <div class="container margin_60_35">
                <div class="row">
                    <div class="col-lg-3 col-md-12">
                        <p>
                       
                                <a href="index.html" title="Findoctor"><img src="img/logo.png" data-retina="true" alt="" width="163" height="36"></a>
                        </p>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <h5>About</h5>
                        <ul class="links">
                            <li><a href="contacts.html">About us</a></li>
                            <li><a href="login.html">Login</a></li>
                            <li><a href="register_supplier.html">Register</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <h5>Useful links</h5>
                        <ul class="links">
                            <li><a href="http://www.civil.hku.hk/cicid/3_events.htm">HKCICID</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <h5>Contact with Us</h5>
                        <ul class="contacts">
                            <li><a href="tel://61280932400"><i class="icon_mobile"></i> To be announced</a></li>
                            <li><a href="mailto:info@findoctor.com"><i class="icon_mail_alt"></i> help@findmic.com</a></li>
                        </ul>
                        <div class="follow_us">
                            <h5>Follow us</h5>
                            <ul>
                                <li><a href="#0"><i class="social_facebook"></i></a></li>
                                <li><a href="#0"><i class="social_twitter"></i></a></li>
                                <li><a href="#0"><i class="social_linkedin"></i></a></li>
                                <li><a href="#0"><i class="social_instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!--/row-->
                <hr>
                <div class="row">
                    <div class="col-md-8">
                        <ul id="additional_links">
                            <li><a href="#0">Terms and conditions</a></li>
                            <li><a href="#0">Privacy</a></li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <div id="copy">© 2018 FindMiC</div>
                    </div>
                </div>
            </div>
        </footer>
        <!--/footer-->	

	<div id="toTop"></div>
	<!-- Back to top button -->

	<!-- COMMON SCRIPTS -->
	<script src="js/jquery-2.2.4.min.js"></script>
	<script src="js/common_scripts.min.js"></script>
	<script src="js/functions.js"></script>
   	
	<!-- SPECIFIC SCRIPTS -->
    <script src="js/bootstrap-datepicker.js"></script>
	<script>
		$('#calendar').datepicker({
			todayHighlight: true,
			daysOfWeekDisabled: [0],
			weekStart: 1,
			format: "yyyy-mm-dd",
			datesDisabled: ["2017/10/20", "2017/11/21", "2017/12/21", "2018/01/21", "2018/02/21", "2018/03/21"],
		});
	</script>
         <script type="text/javascript">
        //js本地图片预览，兼容ie[6-9]、火狐、Chrome17+、Opera11+、Maxthon3
        function PreviewImage(fileObj, imgPreviewId, divPreviewId) {
            var allowExtention = ".jpg,.bmp,.gif,.png"; //允许上传文件的后缀名document.getElementById("hfAllowPicSuffix").value;
            var extention = fileObj.value.substring(fileObj.value.lastIndexOf(".") + 1).toLowerCase();
            var browserVersion = window.navigator.userAgent.toUpperCase();
            if (allowExtention.indexOf(extention) > -1) {
                if (fileObj.files) {//HTML5实现预览，兼容chrome、火狐7+等
                    if (window.FileReader) {
                        var reader = new FileReader();
                        reader.onload = function (e) {
                            document.getElementById(imgPreviewId).setAttribute("src", e.target.result);
                        }
                        reader.readAsDataURL(fileObj.files[0]);
                    } else if (browserVersion.indexOf("SAFARI") > -1) {
                        alert("不支持Safari6.0以下浏览器的图片预览!");
                    }
                } else if (browserVersion.indexOf("MSIE") > -1) {
                    if (browserVersion.indexOf("MSIE 6") > -1) {//ie6
                        document.getElementById(imgPreviewId).setAttribute("src", fileObj.value);
                    } else {//ie[7-9]
                        fileObj.select();
                        if (browserVersion.indexOf("MSIE 9") > -1)
                            fileObj.blur(); //不加上document.selection.createRange().text在ie9会拒绝访问
                        var newPreview = document.getElementById(divPreviewId + "New");
                        if (newPreview == null) {
                            newPreview = document.createElement("div");
                            newPreview.setAttribute("id", divPreviewId + "New");
                            newPreview.style.width = document.getElementById(imgPreviewId).width + "px";
                            newPreview.style.height = document.getElementById(imgPreviewId).height + "px";
                            newPreview.style.border = "solid 1px #d2e2e2";
                        }
                        newPreview.style.filter = "progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod='scale',src='" + document.selection.createRange().text + "')";
                        var tempDivPreview = document.getElementById(divPreviewId);
                        tempDivPreview.parentNode.insertBefore(newPreview, tempDivPreview);
                        tempDivPreview.style.display = "none";
                    }
                } else if (browserVersion.indexOf("FIREFOX") > -1) {//firefox
                    var firefoxVersion = parseFloat(browserVersion.toLowerCase().match(/firefox\/([\d.]+)/)[1]);
                    if (firefoxVersion < 7) {//firefox7以下版本
                        document.getElementById(imgPreviewId).setAttribute("src", fileObj.files[0].getAsDataURL());
                    } else {//firefox7.0+                    
                        document.getElementById(imgPreviewId).setAttribute("src", window.URL.createObjectURL(fileObj.files[0]));
                    }
                } else {
                    document.getElementById(imgPreviewId).setAttribute("src", fileObj.value);
                }
            } else {
                alert("仅支持" + allowExtention + "为后缀名的文件!");
                fileObj.value = ""; //清空选中文件
                if (browserVersion.indexOf("MSIE") > -1) {
                    fileObj.select();
                    document.selection.clear();
                }
                fileObj.outerHTML = fileObj.outerHTML;
            }
            return fileObj.value;    //返回路径
        }
    </script>
</body>
</html>